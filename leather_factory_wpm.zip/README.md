# 🏭 Leather Factory Worker Performance Management System
## Production-Ready Commercial Application

---

## 📋 System Overview

A complete, real-time Worker Performance Management System built for leather goods factories.
Supports Android, iOS, and Web platforms with offline capability.

---

## 🏗️ Architecture

```
leather_factory_wpm/
├── backend/                    # FastAPI Backend
│   ├── app/
│   │   ├── api/v1/endpoints/  # REST API Routes
│   │   ├── core/              # Config, Security, Dependencies
│   │   ├── db/                # Database + Migrations
│   │   ├── models/            # SQLAlchemy ORM Models
│   │   ├── schemas/           # Pydantic Schemas
│   │   ├── services/          # Business Logic
│   │   ├── repositories/      # Data Access Layer
│   │   ├── websocket/         # WebSocket Manager
│   │   └── utils/             # Utilities
│   └── tests/
├── flutter_app/               # Flutter Frontend
│   └── lib/
│       ├── core/              # Constants, Errors, Network
│       ├── data/              # Data Layer
│       ├── domain/            # Business Layer
│       └── presentation/      # UI Layer
├── docker/                    # Docker + Nginx configs
└── docs/                      # API Documentation
```

---

## 🚀 Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Flutter 3.x (Android/iOS/Web) |
| State Management | Riverpod 2.x |
| Backend | FastAPI (Python 3.11) |
| Database | PostgreSQL 15 |
| ORM | SQLAlchemy 2.x |
| Migrations | Alembic |
| Realtime | WebSocket (FastAPI native) |
| Auth | JWT + Refresh Tokens |
| Cache | Redis |
| Reverse Proxy | Nginx |
| Container | Docker + Docker Compose |

---

## 👥 Roles & Permissions

| Role | Permissions |
|------|------------|
| Super Admin | Full system access, manage factory admins |
| Factory Admin | Manage workers, departments, production lines |
| Supervisor | Enter production data, quality data, attendance |
| Worker | View own performance, rankings |

---

## ⚡ Realtime Features

- Dashboard metrics update instantly on data entry
- Rankings recalculate in real-time
- Attendance status broadcasts to all connected clients
- Defect alerts push immediately to supervisors
- Bonus eligibility notifications fire automatically

---

## 📦 Modules

1. **Authentication** - JWT, Refresh Tokens, RBAC
2. **Attendance** - QR, RFID, Manual, Face Recognition
3. **Production** - Daily targets, completed quantity, efficiency
4. **Quality** - Defect tracking, quality scores
5. **Performance** - Daily/Weekly/Monthly scoring, leaderboard
6. **Reports** - PDF, Excel, CSV with filters
7. **Admin** - Worker CRUD, departments, production lines
8. **Notifications** - Push notifications, alerts
