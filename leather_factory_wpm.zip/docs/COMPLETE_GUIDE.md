# 🏭 Leather Factory WPM — Complete Production Guide

---

## 1. DATABASE SCHEMA (PostgreSQL)

```sql
-- Run this in PostgreSQL before Alembic migrations

CREATE EXTENSION IF NOT EXISTS "pgcrypto";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Enums
CREATE TYPE user_role AS ENUM ('super_admin','factory_admin','supervisor','worker');
CREATE TYPE attendance_status AS ENUM ('present','absent','late','half_day','on_leave');
CREATE TYPE attendance_method AS ENUM ('qr_code','rfid','manual','face_recognition');
CREATE TYPE shift_type AS ENUM ('morning','afternoon','night');
CREATE TYPE gender_type AS ENUM ('male','female','other');
CREATE TYPE notification_type AS ENUM (
  'attendance_reminder','target_miss','bonus_eligible','performance_report','system'
);

-- factories
CREATE TABLE factories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(200) NOT NULL,
  code VARCHAR(20) NOT NULL UNIQUE,
  address TEXT, city VARCHAR(100), country VARCHAR(100) DEFAULT 'Bangladesh',
  phone VARCHAR(20), email VARCHAR(200), logo_url VARCHAR(500),
  timezone VARCHAR(50) DEFAULT 'Asia/Dhaka',
  is_active BOOLEAN DEFAULT TRUE,
  settings JSONB,
  is_deleted BOOLEAN DEFAULT FALSE, deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- departments
CREATE TABLE departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  name VARCHAR(200) NOT NULL, code VARCHAR(20) NOT NULL,
  description TEXT, manager_id UUID,
  is_active BOOLEAN DEFAULT TRUE,
  is_deleted BOOLEAN DEFAULT FALSE, deleted_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(factory_id, code)
);

-- production_lines
CREATE TABLE production_lines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  name VARCHAR(200) NOT NULL, code VARCHAR(20) NOT NULL,
  capacity INT, is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(factory_id, code)
);

-- users (workers, supervisors, admins)
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  factory_id UUID REFERENCES factories(id) ON DELETE SET NULL,
  department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
  production_line_id UUID REFERENCES production_lines(id) ON DELETE SET NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  hashed_password VARCHAR(255) NOT NULL,
  role user_role NOT NULL,
  employee_id VARCHAR(50) NOT NULL UNIQUE,
  first_name VARCHAR(100) NOT NULL, last_name VARCHAR(100) NOT NULL,
  gender gender_type, date_of_birth DATE,
  phone VARCHAR(20), address TEXT,
  profile_photo_url VARCHAR(500), face_encoding TEXT,
  designation VARCHAR(100), shift shift_type,
  join_date DATE, daily_target INT, base_salary NUMERIC(12,2),
  rfid_card_number VARCHAR(100) UNIQUE, qr_code VARCHAR(500) UNIQUE,
  is_active BOOLEAN DEFAULT TRUE, is_verified BOOLEAN DEFAULT FALSE,
  last_login TIMESTAMPTZ, fcm_token VARCHAR(500),
  is_deleted BOOLEAN DEFAULT FALSE, deleted_at TIMESTAMPTZ, deleted_by UUID,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX ix_users_factory ON users(factory_id);
CREATE INDEX ix_users_role ON users(role);
CREATE INDEX ix_users_email ON users(email);
CREATE INDEX ix_users_employee_id ON users(employee_id);

-- attendance_records
CREATE TABLE attendance_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  recorded_by UUID REFERENCES users(id) ON DELETE SET NULL,
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  check_in_time TIMESTAMPTZ, check_out_time TIMESTAMPTZ,
  status attendance_status NOT NULL DEFAULT 'absent',
  method attendance_method NOT NULL DEFAULT 'manual',
  shift shift_type, notes TEXT,
  overtime_hours NUMERIC(4,2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(worker_id, date)
);

CREATE INDEX ix_attendance_worker ON attendance_records(worker_id);
CREATE INDEX ix_attendance_date ON attendance_records(date);
CREATE INDEX ix_attendance_factory_date ON attendance_records(factory_id, date);

-- production_records
CREATE TABLE production_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  supervisor_id UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  production_line_id UUID REFERENCES production_lines(id) ON DELETE SET NULL,
  product_type_id UUID,
  date DATE NOT NULL, shift shift_type,
  daily_target INT NOT NULL CHECK (daily_target > 0),
  completed_quantity INT NOT NULL DEFAULT 0 CHECK (completed_quantity >= 0),
  efficiency NUMERIC(6,2) NOT NULL DEFAULT 0
    CHECK (efficiency >= 0 AND efficiency <= 999),
  working_hours NUMERIC(4,2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(worker_id, date, shift)
);

CREATE INDEX ix_production_worker ON production_records(worker_id);
CREATE INDEX ix_production_date ON production_records(date);
CREATE INDEX ix_production_factory_date ON production_records(factory_id, date);

-- quality_records
CREATE TABLE quality_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  production_record_id UUID NOT NULL REFERENCES production_records(id) ON DELETE CASCADE,
  worker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  supervisor_id UUID NOT NULL REFERENCES users(id) ON DELETE SET NULL,
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  produced_quantity INT NOT NULL CHECK (produced_quantity > 0),
  defective_quantity INT NOT NULL DEFAULT 0 CHECK (defective_quantity >= 0),
  quality_score NUMERIC(6,2) NOT NULL CHECK (quality_score BETWEEN 0 AND 100),
  defect_categories JSONB, notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  CHECK (defective_quantity <= produced_quantity)
);

-- performance_scores
CREATE TABLE performance_scores (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  worker_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  factory_id UUID NOT NULL REFERENCES factories(id) ON DELETE CASCADE,
  score_date DATE NOT NULL,
  period_type VARCHAR(20) NOT NULL CHECK (period_type IN ('daily','weekly','monthly')),
  period_start DATE NOT NULL, period_end DATE NOT NULL,
  efficiency_score NUMERIC(6,2) NOT NULL DEFAULT 0,
  quality_score NUMERIC(6,2) NOT NULL DEFAULT 0,
  attendance_score NUMERIC(6,2) NOT NULL DEFAULT 0,
  total_score NUMERIC(6,2) NOT NULL DEFAULT 0,
  rank INT, total_workers INT,
  is_bonus_eligible BOOLEAN DEFAULT FALSE,
  bonus_amount NUMERIC(12,2),
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(worker_id, period_type, period_start)
);

CREATE INDEX ix_perf_factory_period ON performance_scores(factory_id, period_type, period_start);
CREATE INDEX ix_perf_total_score ON performance_scores(total_score DESC);

-- audit_logs
CREATE TABLE audit_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID, factory_id UUID,
  timestamp TIMESTAMPTZ DEFAULT NOW(),
  action VARCHAR(100) NOT NULL,
  resource VARCHAR(100) NOT NULL,
  resource_id VARCHAR(100),
  old_values JSONB, new_values JSONB,
  ip_address VARCHAR(50), user_agent VARCHAR(500)
);

CREATE INDEX ix_audit_timestamp ON audit_logs(timestamp DESC);
CREATE INDEX ix_audit_user ON audit_logs(user_id);
```

---

## 2. API DOCUMENTATION

### Base URL
```
https://yourdomain.com/api/v1
```

### Authentication
All endpoints (except `/auth/login`) require:
```
Authorization: Bearer <access_token>
```

---

### AUTH ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/auth/login` | Login → access + refresh tokens |
| POST | `/auth/refresh` | Refresh access token |
| POST | `/auth/logout` | Revoke refresh token |
| GET | `/auth/me` | Get current user |
| POST | `/auth/change-password` | Change password |

**Login Request:**
```json
{ "email": "supervisor@factory.com", "password": "securepass123" }
```
**Login Response:**
```json
{
  "access_token": "eyJhbGciOiJIUzI1NiJ9...",
  "refresh_token": "eyJhbGciOiJIUzI1NiJ9...",
  "token_type": "bearer",
  "expires_in": 1800,
  "user": { "id": "uuid", "role": "supervisor", "factory_id": "uuid", ... }
}
```

---

### WORKERS ENDPOINTS

| Method | Endpoint | Role |
|--------|----------|------|
| POST | `/workers` | factory_admin+ |
| GET | `/workers?factory_id=&role=&search=` | supervisor+ |
| GET | `/workers/{id}` | all |
| PATCH | `/workers/{id}` | factory_admin+ |
| DELETE | `/workers/{id}` | factory_admin+ |
| POST | `/workers/{id}/transfer` | factory_admin+ |
| GET | `/workers/{id}/qr-code` | supervisor+ |

---

### ATTENDANCE ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/attendance` | Manual mark attendance |
| POST | `/attendance/qr-scan` | QR code scan |
| POST | `/attendance/rfid-scan` | RFID card swipe |
| GET | `/attendance/summary?factory_id=` | Daily summary |
| GET | `/attendance?factory_id=&date=` | List records |

**Mark Attendance:**
```json
{
  "worker_id": "uuid",
  "date": "2024-01-15",
  "status": "present",
  "method": "manual",
  "check_in_time": "2024-01-15T06:00:00Z",
  "shift": "morning"
}
```

---

### PRODUCTION ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/production` | Enter production data → triggers realtime |
| PATCH | `/production/{id}` | Update record → triggers realtime |
| GET | `/production?factory_id=&date_from=` | List records |
| GET | `/production/summary?factory_id=` | Daily summary |

**Enter Production (triggers realtime broadcast):**
```json
{
  "worker_id": "uuid",
  "factory_id": "uuid",
  "date": "2024-01-15",
  "shift": "morning",
  "daily_target": 100,
  "completed_quantity": 95,
  "working_hours": 8
}
```
→ Server calculates: `efficiency = 95/100 * 100 = 95.0%`

---

### QUALITY ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/quality` | Enter quality data |
| GET | `/quality?factory_id=` | List records |

```json
{
  "production_record_id": "uuid",
  "worker_id": "uuid",
  "factory_id": "uuid",
  "date": "2024-01-15",
  "produced_quantity": 95,
  "defective_quantity": 3,
  "defect_categories": { "stitching": 2, "cut": 1 }
}
```
→ Server calculates: `quality_score = (95-3)/95 * 100 = 96.84%`

---

### LEADERBOARD ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/leaderboard/daily?factory_id=` | Daily top 10 |
| GET | `/leaderboard/weekly?factory_id=` | Weekly top 10 |
| GET | `/leaderboard/monthly?factory_id=` | Monthly top 10 |

---

### REPORTS ENDPOINTS

| Method | Endpoint | Formats |
|--------|----------|---------|
| GET | `/reports/attendance?factory_id=&start_date=&end_date=&format=pdf` | pdf, excel, csv |
| GET | `/reports/production?factory_id=&start_date=&end_date=&format=excel` | pdf, excel, csv |
| GET | `/reports/performance?factory_id=&period_type=monthly&start_date=` | pdf, excel, csv |

---

### WEBSOCKET

```
ws://yourdomain.com/ws?token=<access_token>
```

**Events received from server:**
```
attendance_marked        → { worker_id, status, timestamp }
production_entered       → { production, worker_efficiency }
quality_entered          → { quality, new_quality_score }
leaderboard_update       → { period_type, leaderboard: [...top10] }
performance_recalculated → { worker_id, scores }
bonus_eligible           → { title, body, period_type }
notification             → { type, title, body }
ping                     → heartbeat (reply with pong)
```

**Events sent to server:**
```json
{ "event": "pong" }
{ "event": "ping" }
```

---

## 3. PERFORMANCE FORMULA

```
Efficiency Score  = avg(completed / target × 100)  [across period]
Quality Score     = avg((produced - defective) / produced × 100)
Attendance Score  = (present_days / total_days × 100)

Total Score = (Efficiency × 0.40) + (Quality × 0.35) + (Attendance × 0.25)

Bonus Eligible = Efficiency ≥ 90% AND Quality ≥ 95% AND Attendance ≥ 95%
```

---

## 4. DEPLOYMENT GUIDE

### Prerequisites
- Ubuntu 22.04 LTS server
- Docker + Docker Compose
- Domain with SSL certificate

### Step 1: Server Setup
```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y docker.io docker-compose git

# Create app user
sudo useradd -m -s /bin/bash wpmapp
sudo usermod -aG docker wpmapp
```

### Step 2: Clone & Configure
```bash
git clone https://github.com/yourorg/leather-wpm.git /opt/leather-wpm
cd /opt/leather-wpm
cp .env.example .env
nano .env  # Fill in all values
```

### Step 3: .env File
```env
# Database
POSTGRES_USER=wpm_user
POSTGRES_PASSWORD=STRONG_RANDOM_PASSWORD_HERE
POSTGRES_DB=leather_wpm

# Redis
REDIS_PASSWORD=STRONG_REDIS_PASSWORD

# Security
SECRET_KEY=256_BIT_RANDOM_HEX_KEY_HERE

# App
ENVIRONMENT=production
DEBUG=false
ALLOWED_ORIGINS=["https://yourdomain.com"]
```

### Step 4: Generate SECRET_KEY
```bash
python3 -c "import secrets; print(secrets.token_hex(32))"
```

### Step 5: SSL Certificate
```bash
sudo apt install -y certbot
certbot certonly --standalone -d yourdomain.com
# Cert: /etc/letsencrypt/live/yourdomain.com/fullchain.pem
# Key:  /etc/letsencrypt/live/yourdomain.com/privkey.pem

mkdir -p docker/nginx/ssl
cp /etc/letsencrypt/live/yourdomain.com/fullchain.pem docker/nginx/ssl/cert.pem
cp /etc/letsencrypt/live/yourdomain.com/privkey.pem docker/nginx/ssl/key.pem
```

### Step 6: Launch
```bash
docker-compose up -d
docker-compose logs -f backend  # Watch for successful startup
```

### Step 7: Create Super Admin
```bash
docker-compose exec backend python3 -c "
from app.db.database import AsyncSessionLocal
from app.models.models import User, UserRoleEnum
from app.core.security import get_password_hash
import asyncio, uuid

async def create_admin():
    async with AsyncSessionLocal() as db:
        admin = User(
            email='admin@factory.com',
            hashed_password=get_password_hash('ChangeThis123!'),
            role=UserRoleEnum.SUPER_ADMIN,
            employee_id='SA001',
            first_name='Super',
            last_name='Admin',
            is_active=True,
            is_verified=True,
        )
        db.add(admin)
        await db.commit()
        print('Super admin created!')

asyncio.run(create_admin())
"
```

### Step 8: Verify Health
```bash
curl https://yourdomain.com/health
# Expected: {"status":"ok","app":"Leather Factory WPM","version":"1.0.0"}
```

---

## 5. FLUTTER BUILD & DEPLOY

### Android Release Build
```bash
cd flutter_app
flutter build apk --release
# Output: build/app/outputs/flutter-apk/app-release.apk
```

### iOS Release Build
```bash
flutter build ios --release
# Open in Xcode, archive, distribute
```

### Web Build
```bash
flutter build web --release --web-renderer canvaskit
# Upload build/web/ to web server or CDN
```

### Update API URL
Edit `lib/core/constants/app_constants.dart`:
```dart
static const String baseUrl = 'https://yourdomain.com/api/v1';
static const String wsUrl = 'wss://yourdomain.com/ws';
```

---

## 6. SECURITY CHECKLIST

- [x] Passwords hashed with bcrypt (cost factor 12)
- [x] JWT with short expiry (30 min) + refresh rotation
- [x] Refresh tokens stored as SHA-256 hashes
- [x] RBAC on every endpoint
- [x] Factory-scoped data isolation
- [x] SQL injection prevented (SQLAlchemy ORM)
- [x] CORS configured with allowed origins whitelist
- [x] HTTPS enforced via Nginx redirect
- [x] Soft deletes (no data permanently lost)
- [x] Audit log on all mutations
- [x] Rate limiting recommended (add slowapi)
- [x] Input validation via Pydantic
- [x] Database constraints (CHECK, UNIQUE, FK)
- [x] Sensitive data in environment variables only

**Additional Production Security:**
```bash
# Install fail2ban
sudo apt install fail2ban

# PostgreSQL: disable remote access (use Docker network only)
# Add to postgresql.conf:
# listen_addresses = 'localhost'

# Regular backups
docker-compose exec db pg_dump -U wpm_user leather_wpm > backup_$(date +%Y%m%d).sql
```

---

## 7. MONITORING

```bash
# View logs
docker-compose logs -f backend
docker-compose logs -f db

# Container stats
docker stats

# DB connections
docker-compose exec db psql -U wpm_user -d leather_wpm \
  -c "SELECT count(*) FROM pg_stat_activity;"
```

---

## 8. TESTING STRATEGY

### Backend Tests
```bash
cd backend
pytest tests/ -v --asyncio-mode=auto

# Test coverage
pytest tests/ --cov=app --cov-report=html
```

### Test Categories
1. **Unit Tests** — Services (performance calculation, formulas)
2. **Integration Tests** — API endpoints with test DB
3. **WebSocket Tests** — Connection, broadcast, reconnect
4. **Load Tests** — k6 or Locust for concurrent users

### Sample Test
```python
# tests/test_performance.py
async def test_efficiency_calculation():
    assert calculate_efficiency(90, 100) == 90.0
    assert calculate_efficiency(110, 100) == 110.0
    assert calculate_efficiency(0, 100) == 0.0

async def test_bonus_eligibility():
    assert check_bonus(95, 97, 98) == True   # All above threshold
    assert check_bonus(89, 97, 98) == False  # Efficiency below 90%
```

---

## 9. FOLDER STRUCTURE (Complete)

```
leather_factory_wpm/
├── backend/
│   ├── app/
│   │   ├── main.py                          ← FastAPI app
│   │   ├── api/v1/endpoints/
│   │   │   ├── auth.py                      ← Login, refresh, logout
│   │   │   ├── attendance.py                ← QR, RFID, manual
│   │   │   ├── production.py                ← Production data + realtime
│   │   │   ├── workers_quality_ws.py        ← Workers, quality, leaderboard, WS
│   │   │   └── reports.py                   ← PDF, Excel, CSV reports
│   │   ├── core/
│   │   │   ├── config.py                    ← All settings
│   │   │   ├── security.py                  ← JWT, bcrypt, RBAC
│   │   │   └── dependencies.py              ← FastAPI deps, auth guards
│   │   ├── db/
│   │   │   ├── database.py                  ← Async engine, session
│   │   │   └── migrations/env.py            ← Alembic config
│   │   ├── models/models.py                 ← All SQLAlchemy ORM models
│   │   ├── schemas/schemas.py               ← All Pydantic schemas
│   │   ├── services/performance_service.py  ← Business logic + realtime
│   │   └── websocket/manager.py             ← WS connection manager
│   ├── requirements.txt
│   └── Dockerfile
├── flutter_app/
│   ├── lib/
│   │   ├── main.dart                        ← App entry point
│   │   ├── core/
│   │   │   ├── constants/
│   │   │   │   ├── app_constants.dart       ← API URLs, keys
│   │   │   │   └── app_theme.dart           ← Material 3 light+dark
│   │   │   ├── network/
│   │   │   │   ├── api_client.dart          ← Dio + JWT interceptor
│   │   │   │   └── websocket_service.dart   ← WS with auto-reconnect
│   │   │   └── router/app_router.dart       ← GoRouter + auth guards
│   │   └── presentation/
│   │       ├── providers/app_providers.dart  ← All Riverpod providers
│   │       ├── pages/
│   │       │   ├── auth/login_page.dart
│   │       │   ├── dashboard/dashboard_page.dart  ← Realtime dashboard
│   │       │   └── production/production_entry_page.dart
│   │       └── widgets/common/main_scaffold.dart   ← Nav + role menu
│   └── pubspec.yaml
├── docker/
│   └── nginx/nginx.conf                     ← Reverse proxy + WS
├── docker-compose.yml                       ← Full stack
└── README.md
```

---

## 10. SCALABILITY NOTES

- **Horizontal scaling**: Add `--workers N` to uvicorn for multi-core
- **WebSocket at scale**: Replace in-memory manager with Redis Pub/Sub
- **Database**: Add read replicas for reporting queries
- **Caching**: Redis for leaderboard (recalculate every 60s instead of per-write)
- **Background jobs**: Celery for scheduled reports, notification batching
