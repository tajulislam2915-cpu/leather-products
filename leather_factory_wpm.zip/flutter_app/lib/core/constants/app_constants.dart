// lib/core/constants/app_constants.dart

class AppConstants {
  static const String appName = 'Leather Factory WPM';
  static const String appVersion = '1.0.0';

  // API
  static const String baseUrl = 'https://yourdomain.com/api/v1';
  static const String wsUrl = 'wss://yourdomain.com/ws';

  // Storage Keys
  static const String accessTokenKey = 'access_token';
  static const String refreshTokenKey = 'refresh_token';
  static const String userDataKey = 'user_data';
  static const String factoryIdKey = 'factory_id';
  static const String themeKey = 'theme_mode';

  // Timeouts
  static const int connectTimeout = 30000;
  static const int receiveTimeout = 30000;

  // Pagination
  static const int pageSize = 20;

  // WS reconnect
  static const int wsReconnectDelay = 3; // seconds
  static const int wsMaxRetries = 5;

  // Performance thresholds
  static const double excellentThreshold = 90.0;
  static const double goodThreshold = 75.0;
  static const double averageThreshold = 60.0;
}

class ApiEndpoints {
  // Auth
  static const String login = '/auth/login';
  static const String refresh = '/auth/refresh';
  static const String logout = '/auth/logout';
  static const String me = '/auth/me';
  static const String changePassword = '/auth/change-password';

  // Workers
  static const String workers = '/workers';
  static String worker(String id) => '/workers/$id';
  static String workerTransfer(String id) => '/workers/$id/transfer';
  static String workerQR(String id) => '/workers/$id/qr-code';

  // Attendance
  static const String attendance = '/attendance';
  static const String attendanceQR = '/attendance/qr-scan';
  static const String attendanceRFID = '/attendance/rfid-scan';
  static const String attendanceSummary = '/attendance/summary';

  // Production
  static const String production = '/production';
  static const String productionSummary = '/production/summary';
  static String productionRecord(String id) => '/production/$id';

  // Quality
  static const String quality = '/quality';

  // Leaderboard
  static String leaderboard(String period) => '/leaderboard/$period';

  // Reports
  static const String reportAttendance = '/reports/attendance';
  static const String reportProduction = '/reports/production';
  static const String reportPerformance = '/reports/performance';
}
