// lib/core/router/app_router.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../presentation/providers/app_providers.dart';
import '../../presentation/pages/auth/login_page.dart';
import '../../presentation/pages/dashboard/dashboard_page.dart';
import '../../presentation/pages/production/production_entry_page.dart';
import '../../presentation/widgets/common/main_scaffold.dart';

final routerProvider = Provider<GoRouter>((ref) {
  final authState = ref.watch(authProvider);

  return GoRouter(
    initialLocation: authState.isAuthenticated ? '/dashboard' : '/login',
    redirect: (context, state) {
      final isLoggedIn = ref.read(authProvider).isAuthenticated;
      final isLoginRoute = state.matchedLocation == '/login';
      if (!isLoggedIn && !isLoginRoute) return '/login';
      if (isLoggedIn && isLoginRoute) return '/dashboard';
      return null;
    },
    routes: [
      GoRoute(path: '/login', builder: (_, __) => const LoginPage()),
      ShellRoute(
        builder: (context, state, child) => MainScaffold(child: child),
        routes: [
          GoRoute(path: '/dashboard', builder: (_, __) => const DashboardPage()),
          GoRoute(path: '/production', builder: (_, __) => const ProductionEntryPage()),
          GoRoute(path: '/attendance', builder: (_, __) => const _PlaceholderPage(title: 'Attendance')),
          GoRoute(path: '/leaderboard', builder: (_, __) => const _PlaceholderPage(title: 'Leaderboard')),
          GoRoute(path: '/workers', builder: (_, __) => const _PlaceholderPage(title: 'Workers')),
          GoRoute(path: '/reports', builder: (_, __) => const _PlaceholderPage(title: 'Reports')),
          GoRoute(path: '/quality', builder: (_, __) => const _PlaceholderPage(title: 'Quality')),
          GoRoute(path: '/profile', builder: (_, __) => const _PlaceholderPage(title: 'Profile')),
        ],
      ),
    ],
  );
});

class _PlaceholderPage extends StatelessWidget {
  final String title;
  const _PlaceholderPage({required this.title});

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: Center(child: Text('$title Module', style: Theme.of(context).textTheme.headlineSmall)),
  );
}
