// lib/core/network/websocket_service.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/io.dart';
import '../constants/app_constants.dart';

enum WsConnectionState { disconnected, connecting, connected, reconnecting }

class WebSocketService {
  static final WebSocketService _instance = WebSocketService._internal();
  factory WebSocketService() => _instance;
  WebSocketService._internal();

  WebSocketChannel? _channel;
  StreamSubscription? _subscription;
  Timer? _reconnectTimer;
  Timer? _heartbeatTimer;

  int _retryCount = 0;
  WsConnectionState _state = WsConnectionState.disconnected;

  final _stateController = StreamController<WsConnectionState>.broadcast();
  final _eventController = StreamController<Map<String, dynamic>>.broadcast();

  Stream<WsConnectionState> get stateStream => _stateController.stream;
  Stream<Map<String, dynamic>> get eventStream => _eventController.stream;
  WsConnectionState get state => _state;

  final FlutterSecureStorage _storage = const FlutterSecureStorage();

  Future<void> connect() async {
    if (_state == WsConnectionState.connected ||
        _state == WsConnectionState.connecting) return;

    _setState(WsConnectionState.connecting);

    try {
      final token = await _storage.read(key: AppConstants.accessTokenKey);
      if (token == null) {
        _setState(WsConnectionState.disconnected);
        return;
      }

      final uri = Uri.parse('${AppConstants.wsUrl}?token=$token');
      _channel = IOWebSocketChannel.connect(
        uri,
        pingInterval: const Duration(seconds: 30),
      );

      _subscription = _channel!.stream.listen(
        _onMessage,
        onError: _onError,
        onDone: _onDone,
      );

      _setState(WsConnectionState.connected);
      _retryCount = 0;
      _startHeartbeat();
    } catch (e) {
      print('WS connect error: $e');
      _scheduleReconnect();
    }
  }

  void _onMessage(dynamic data) {
    try {
      final Map<String, dynamic> json = jsonDecode(data as String);
      final event = json['event'] as String?;

      if (event == 'ping') {
        _send({'event': 'pong'});
        return;
      }
      _eventController.add(json);
    } catch (e) {
      print('WS parse error: $e');
    }
  }

  void _onError(dynamic error) {
    print('WS error: $error');
    _setState(WsConnectionState.disconnected);
    _scheduleReconnect();
  }

  void _onDone() {
    print('WS closed');
    _setState(WsConnectionState.disconnected);
    _scheduleReconnect();
  }

  void _scheduleReconnect() {
    if (_retryCount >= AppConstants.wsMaxRetries) return;
    _retryCount++;
    _setState(WsConnectionState.reconnecting);
    _reconnectTimer?.cancel();
    final delay = Duration(seconds: AppConstants.wsReconnectDelay * _retryCount);
    _reconnectTimer = Timer(delay, connect);
  }

  void _startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 30), (_) {
      if (_state == WsConnectionState.connected) {
        _send({'event': 'ping'});
      }
    });
  }

  void _send(Map<String, dynamic> data) {
    try {
      _channel?.sink.add(jsonEncode(data));
    } catch (_) {}
  }

  void _setState(WsConnectionState newState) {
    _state = newState;
    _stateController.add(newState);
  }

  void disconnect() {
    _heartbeatTimer?.cancel();
    _reconnectTimer?.cancel();
    _subscription?.cancel();
    _channel?.sink.close();
    _setState(WsConnectionState.disconnected);
    _retryCount = 0;
  }

  void dispose() {
    disconnect();
    _stateController.close();
    _eventController.close();
  }
}
