// lib/presentation/widgets/common/main_scaffold.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/app_providers.dart';
import '../../../core/constants/app_theme.dart';

class MainScaffold extends ConsumerWidget {
  final Widget child;
  const MainScaffold({super.key, required this.child});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final auth = ref.watch(authProvider);
    final role = auth.user?['role'] ?? 'worker';
    final location = GoRouterState.of(context).matchedLocation;
    final unread = ref.watch(unreadCountProvider);

    final navItems = _getNavItems(role);
    final currentIndex = navItems.indexWhere((item) => location.startsWith(item.route));

    return Scaffold(
      body: child,
      bottomNavigationBar: NavigationBar(
        selectedIndex: currentIndex < 0 ? 0 : currentIndex,
        onDestinationSelected: (i) => context.go(navItems[i].route),
        destinations: navItems.map((item) {
          Widget icon = Icon(item.icon);
          if (item.route == '/profile' && unread > 0) {
            icon = Badge(label: Text('$unread'), child: icon);
          }
          return NavigationDestination(
            icon: icon,
            selectedIcon: Icon(item.activeIcon),
            label: item.label,
          );
        }).toList(),
      ),
    );
  }

  List<_NavItem> _getNavItems(String role) {
    final base = [
      _NavItem('/dashboard', 'Dashboard', Icons.dashboard_outlined, Icons.dashboard),
      _NavItem('/leaderboard', 'Rankings', Icons.leaderboard_outlined, Icons.leaderboard),
    ];

    if (role == 'worker') {
      base.add(_NavItem('/profile', 'Profile', Icons.person_outline, Icons.person));
      return base;
    }

    // Supervisor+
    base.addAll([
      _NavItem('/attendance', 'Attendance', Icons.how_to_reg_outlined, Icons.how_to_reg),
      _NavItem('/production', 'Production', Icons.factory_outlined, Icons.factory),
      _NavItem('/quality', 'Quality', Icons.verified_outlined, Icons.verified),
    ]);

    if (role == 'factory_admin' || role == 'super_admin') {
      base.addAll([
        _NavItem('/workers', 'Workers', Icons.people_outline, Icons.people),
        _NavItem('/reports', 'Reports', Icons.assessment_outlined, Icons.assessment),
      ]);
    }

    base.add(_NavItem('/profile', 'Profile', Icons.person_outline, Icons.person));
    return base;
  }
}

class _NavItem {
  final String route, label;
  final IconData icon, activeIcon;
  const _NavItem(this.route, this.label, this.icon, this.activeIcon);
}
