// lib/presentation/providers/app_providers.dart
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:dio/dio.dart';

import '../../core/constants/app_constants.dart';
import '../../core/network/api_client.dart';
import '../../core/network/websocket_service.dart';

// ── Singletons ────────────────────────────────────────────────────────────────
final apiClientProvider = Provider<ApiClient>((ref) => ApiClient());
final storageProvider = Provider<FlutterSecureStorage>((ref) => const FlutterSecureStorage());
final wsServiceProvider = Provider<WebSocketService>((ref) {
  final ws = WebSocketService();
  ref.onDispose(ws.dispose);
  return ws;
});

// ── Theme ─────────────────────────────────────────────────────────────────────
final themeModeProvider = StateNotifierProvider<ThemeModeNotifier, ThemeMode>((ref) {
  return ThemeModeNotifier();
});

class ThemeModeNotifier extends StateNotifier<ThemeMode> {
  ThemeModeNotifier() : super(ThemeMode.light);
  void toggle() => state = state == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;
  void setMode(ThemeMode mode) => state = mode;
}

// ── Auth State ─────────────────────────────────────────────────────────────────
class AuthState {
  final bool isAuthenticated;
  final Map<String, dynamic>? user;
  final bool isLoading;
  final String? error;
  const AuthState({this.isAuthenticated = false, this.user, this.isLoading = false, this.error});
  AuthState copyWith({bool? isAuthenticated, Map<String, dynamic>? user, bool? isLoading, String? error}) =>
      AuthState(
        isAuthenticated: isAuthenticated ?? this.isAuthenticated,
        user: user ?? this.user,
        isLoading: isLoading ?? this.isLoading,
        error: error,
      );
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>((ref) {
  return AuthNotifier(ref.read(apiClientProvider), ref.read(storageProvider), ref);
});

class AuthNotifier extends StateNotifier<AuthState> {
  final ApiClient _api;
  final FlutterSecureStorage _storage;
  final Ref _ref;

  AuthNotifier(this._api, this._storage, this._ref) : super(const AuthState()) {
    _checkStoredAuth();
  }

  Future<void> _checkStoredAuth() async {
    final token = await _storage.read(key: AppConstants.accessTokenKey);
    final userData = await _storage.read(key: AppConstants.userDataKey);
    if (token != null && userData != null) {
      state = state.copyWith(
        isAuthenticated: true,
        user: jsonDecode(userData),
      );
      _ref.read(wsServiceProvider).connect();
    }
  }

  Future<bool> login(String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final response = await _api.dio.post(ApiEndpoints.login, data: {
        'email': email,
        'password': password,
      });
      final data = response.data;
      await _storage.write(key: AppConstants.accessTokenKey, value: data['access_token']);
      await _storage.write(key: AppConstants.refreshTokenKey, value: data['refresh_token']);
      await _storage.write(key: AppConstants.userDataKey, value: jsonEncode(data['user']));
      if (data['user']['factory_id'] != null) {
        await _storage.write(key: AppConstants.factoryIdKey, value: data['user']['factory_id']);
      }
      state = state.copyWith(isAuthenticated: true, user: data['user'], isLoading: false);
      _ref.read(wsServiceProvider).connect();
      return true;
    } on DioException catch (e) {
      final msg = e.response?.data['detail'] ?? 'Login failed';
      state = state.copyWith(isLoading: false, error: msg);
      return false;
    }
  }

  Future<void> logout() async {
    try {
      final refresh = await _storage.read(key: AppConstants.refreshTokenKey);
      if (refresh != null) {
        await _api.dio.post(ApiEndpoints.logout, data: {'refresh_token': refresh});
      }
    } catch (_) {}
    await _storage.deleteAll();
    _ref.read(wsServiceProvider).disconnect();
    state = const AuthState();
  }

  String? get role => state.user?['role'];
  String? get factoryId => state.user?['factory_id'];
  String? get userId => state.user?['id'];
}

// ── WebSocket Events Provider ─────────────────────────────────────────────────
final wsEventProvider = StreamProvider<Map<String, dynamic>>((ref) {
  return ref.watch(wsServiceProvider).eventStream;
});

// ── Dashboard State ───────────────────────────────────────────────────────────
class DashboardState {
  final Map<String, dynamic>? attendanceSummary;
  final Map<String, dynamic>? productionSummary;
  final List<Map<String, dynamic>> leaderboard;
  final bool isLoading;
  final DateTime? lastUpdated;

  const DashboardState({
    this.attendanceSummary,
    this.productionSummary,
    this.leaderboard = const [],
    this.isLoading = false,
    this.lastUpdated,
  });

  DashboardState copyWith({
    Map<String, dynamic>? attendanceSummary,
    Map<String, dynamic>? productionSummary,
    List<Map<String, dynamic>>? leaderboard,
    bool? isLoading,
    DateTime? lastUpdated,
  }) => DashboardState(
    attendanceSummary: attendanceSummary ?? this.attendanceSummary,
    productionSummary: productionSummary ?? this.productionSummary,
    leaderboard: leaderboard ?? this.leaderboard,
    isLoading: isLoading ?? this.isLoading,
    lastUpdated: lastUpdated ?? this.lastUpdated,
  );
}

final dashboardProvider = StateNotifierProvider<DashboardNotifier, DashboardState>((ref) {
  final notifier = DashboardNotifier(ref.read(apiClientProvider), ref);
  // Listen for realtime WS updates
  ref.listen(wsEventProvider, (_, next) {
    next.whenData((event) => notifier.handleWsEvent(event));
  });
  return notifier;
});

class DashboardNotifier extends StateNotifier<DashboardState> {
  final ApiClient _api;
  final Ref _ref;

  DashboardNotifier(this._api, this._ref) : super(const DashboardState());

  Future<void> refresh(String factoryId) async {
    state = state.copyWith(isLoading: true);
    try {
      final results = await Future.wait([
        _api.dio.get(ApiEndpoints.attendanceSummary, queryParameters: {'factory_id': factoryId}),
        _api.dio.get(ApiEndpoints.productionSummary, queryParameters: {'factory_id': factoryId}),
        _api.dio.get(ApiEndpoints.leaderboard('daily'), queryParameters: {'factory_id': factoryId, 'limit': 10}),
      ]);
      state = state.copyWith(
        attendanceSummary: results[0].data,
        productionSummary: results[1].data,
        leaderboard: List<Map<String, dynamic>>.from(results[2].data['entries'] ?? []),
        isLoading: false,
        lastUpdated: DateTime.now(),
      );
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }

  void handleWsEvent(Map<String, dynamic> event) {
    final eventType = event['event'] as String?;
    switch (eventType) {
      case 'attendance_marked':
      case 'attendance_summary_update':
        final data = event['data'] as Map<String, dynamic>?;
        if (data != null) {
          state = state.copyWith(
            attendanceSummary: {...?state.attendanceSummary, ...data},
            lastUpdated: DateTime.now(),
          );
        }
        break;
      case 'production_entered':
      case 'production_summary_update':
        final data = event['data'] as Map<String, dynamic>?;
        if (data != null) {
          state = state.copyWith(
            productionSummary: {...?state.productionSummary, ...data},
            lastUpdated: DateTime.now(),
          );
        }
        break;
      case 'leaderboard_update':
        final data = event['data'] as Map<String, dynamic>?;
        if (data != null) {
          final entries = data['leaderboard'] as List?;
          if (entries != null) {
            state = state.copyWith(
              leaderboard: List<Map<String, dynamic>>.from(entries),
              lastUpdated: DateTime.now(),
            );
          }
        }
        break;
    }
  }
}

// ── Workers List Provider ─────────────────────────────────────────────────────
final workersProvider = FutureProvider.family<List<dynamic>, String>((ref, factoryId) async {
  final api = ref.read(apiClientProvider);
  final response = await api.dio.get(ApiEndpoints.workers, queryParameters: {
    'factory_id': factoryId,
    'size': 100,
  });
  return response.data as List;
});

// ── Notifications ─────────────────────────────────────────────────────────────
final notificationsProvider = StateNotifierProvider<NotificationNotifier, List<Map<String, dynamic>>>((ref) {
  final notifier = NotificationNotifier();
  ref.listen(wsEventProvider, (_, next) {
    next.whenData((event) {
      if (event['event'] == 'notification' || event['event'] == 'bonus_eligible') {
        notifier.addNotification(event['data'] as Map<String, dynamic>? ?? event);
      }
    });
  });
  return notifier;
});

class NotificationNotifier extends StateNotifier<List<Map<String, dynamic>>> {
  NotificationNotifier() : super([]);

  void addNotification(Map<String, dynamic> notification) {
    state = [notification, ...state];
  }

  void markRead(int index) {
    final updated = [...state];
    updated[index] = {...updated[index], 'is_read': true};
    state = updated;
  }

  int get unreadCount => state.where((n) => n['is_read'] != true).length;
}

final unreadCountProvider = Provider<int>((ref) {
  return ref.watch(notificationsProvider.notifier).unreadCount;
});
