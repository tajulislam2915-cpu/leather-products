// lib/presentation/pages/production/production_entry_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../providers/app_providers.dart';
import '../../../core/constants/app_theme.dart';
import '../../../core/constants/app_constants.dart';

class ProductionEntryPage extends ConsumerStatefulWidget {
  const ProductionEntryPage({super.key});

  @override
  ConsumerState<ProductionEntryPage> createState() => _ProductionEntryPageState();
}

class _ProductionEntryPageState extends ConsumerState<ProductionEntryPage> {
  final _formKey = GlobalKey<FormState>();
  String? _selectedWorkerId;
  String? _selectedWorkerName;
  final _targetCtrl = TextEditingController();
  final _completedCtrl = TextEditingController();
  final _hoursCtrl = TextEditingController();
  final _notesCtrl = TextEditingController();
  String? _shift;
  DateTime _selectedDate = DateTime.now();
  bool _isSubmitting = false;
  double _efficiency = 0;

  @override
  void dispose() {
    _targetCtrl.dispose();
    _completedCtrl.dispose();
    _hoursCtrl.dispose();
    _notesCtrl.dispose();
    super.dispose();
  }

  void _recalcEfficiency() {
    final target = int.tryParse(_targetCtrl.text) ?? 0;
    final completed = int.tryParse(_completedCtrl.text) ?? 0;
    setState(() {
      _efficiency = target > 0 ? (completed / target * 100).clamp(0, 999) : 0;
    });
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (_selectedWorkerId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select a worker'), backgroundColor: Colors.red));
      return;
    }

    setState(() => _isSubmitting = true);
    try {
      final auth = ref.read(authProvider);
      final api = ref.read(apiClientProvider);

      await api.dio.post(ApiEndpoints.production, data: {
        'worker_id': _selectedWorkerId,
        'factory_id': auth.user?['factory_id'],
        'date': DateFormat('yyyy-MM-dd').format(_selectedDate),
        'shift': _shift,
        'daily_target': int.parse(_targetCtrl.text),
        'completed_quantity': int.parse(_completedCtrl.text),
        'working_hours': _hoursCtrl.text.isNotEmpty ? double.parse(_hoursCtrl.text) : null,
        'notes': _notesCtrl.text.isEmpty ? null : _notesCtrl.text,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Row(children: [
              const Icon(Icons.check_circle, color: Colors.white),
              const SizedBox(width: 8),
              Text('Production data saved! Efficiency: ${_efficiency.toStringAsFixed(1)}%'),
            ]),
            backgroundColor: AppTheme.successColor,
            duration: const Duration(seconds: 3),
          ),
        );
        // Reset form
        _targetCtrl.clear();
        _completedCtrl.clear();
        _hoursCtrl.clear();
        _notesCtrl.clear();
        setState(() {
          _selectedWorkerId = null;
          _selectedWorkerName = null;
          _efficiency = 0;
          _shift = null;
        });
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e'), backgroundColor: Colors.red));
      }
    } finally {
      if (mounted) setState(() => _isSubmitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = ref.watch(authProvider);
    final factoryId = auth.user?['factory_id'];
    final workersAsync = factoryId != null
        ? ref.watch(workersProvider(factoryId))
        : null;

    return Scaffold(
      appBar: AppBar(title: const Text('Enter Production Data')),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Worker Selection
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Worker', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      workersAsync == null
                          ? const Text('Factory not assigned')
                          : workersAsync.when(
                              loading: () => const LinearProgressIndicator(),
                              error: (e, _) => Text('Error: $e'),
                              data: (workers) {
                                final workerList = workers
                                    .where((w) => w['role'] == 'worker')
                                    .toList();
                                return DropdownButtonFormField<String>(
                                  value: _selectedWorkerId,
                                  decoration: const InputDecoration(
                                    labelText: 'Select Worker',
                                    prefixIcon: Icon(Icons.person_outline),
                                  ),
                                  items: workerList.map<DropdownMenuItem<String>>((w) {
                                    return DropdownMenuItem<String>(
                                      value: w['id'],
                                      child: Text('${w['first_name']} ${w['last_name']} (${w['employee_id']})'),
                                    );
                                  }).toList(),
                                  onChanged: (val) {
                                    setState(() {
                                      _selectedWorkerId = val;
                                      final w = workerList.firstWhere((w) => w['id'] == val);
                                      _selectedWorkerName = '${w['first_name']} ${w['last_name']}';
                                      // Auto-fill target from worker profile
                                      if (w['daily_target'] != null) {
                                        _targetCtrl.text = '${w['daily_target']}';
                                        _recalcEfficiency();
                                      }
                                    });
                                  },
                                  validator: (v) => v == null ? 'Select a worker' : null,
                                );
                              },
                            ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Date and Shift
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Date & Shift', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(
                          child: InkWell(
                            onTap: () async {
                              final picked = await showDatePicker(
                                context: context,
                                initialDate: _selectedDate,
                                firstDate: DateTime.now().subtract(const Duration(days: 30)),
                                lastDate: DateTime.now(),
                              );
                              if (picked != null) setState(() => _selectedDate = picked);
                            },
                            child: InputDecorator(
                              decoration: const InputDecoration(
                                labelText: 'Date',
                                prefixIcon: Icon(Icons.calendar_today_outlined),
                              ),
                              child: Text(DateFormat('dd MMM yyyy').format(_selectedDate)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: DropdownButtonFormField<String>(
                            value: _shift,
                            decoration: const InputDecoration(
                              labelText: 'Shift',
                              prefixIcon: Icon(Icons.schedule),
                            ),
                            items: const [
                              DropdownMenuItem(value: 'morning', child: Text('Morning (6-14)')),
                              DropdownMenuItem(value: 'afternoon', child: Text('Afternoon (14-22)')),
                              DropdownMenuItem(value: 'night', child: Text('Night (22-6)')),
                            ],
                            onChanged: (v) => setState(() => _shift = v),
                          ),
                        ),
                      ]),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 12),

              // Production Numbers
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Production Numbers', style: TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 12),
                      Row(children: [
                        Expanded(
                          child: TextFormField(
                            controller: _targetCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Daily Target',
                              prefixIcon: Icon(Icons.flag_outlined),
                            ),
                            onChanged: (_) => _recalcEfficiency(),
                            validator: (v) {
                              final n = int.tryParse(v ?? '');
                              return (n == null || n <= 0) ? 'Enter valid target' : null;
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            controller: _completedCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Completed',
                              prefixIcon: Icon(Icons.check_circle_outline),
                            ),
                            onChanged: (_) => _recalcEfficiency(),
                            validator: (v) {
                              final n = int.tryParse(v ?? '');
                              return (n == null || n < 0) ? 'Enter valid quantity' : null;
                            },
                          ),
                        ),
                      ]),
                      const SizedBox(height: 16),

                      // Live Efficiency Display
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: efficiencyColor(_efficiency).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: efficiencyColor(_efficiency).withOpacity(0.4)),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text('Calculated Efficiency',
                              style: TextStyle(fontWeight: FontWeight.w600)),
                            Row(children: [
                              Icon(Icons.speed, color: efficiencyColor(_efficiency)),
                              const SizedBox(width: 8),
                              Text(
                                '${_efficiency.toStringAsFixed(1)}%',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  color: efficiencyColor(_efficiency),
                                ),
                              ),
                            ]),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _hoursCtrl,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(
                          labelText: 'Working Hours (optional)',
                          prefixIcon: Icon(Icons.timer_outlined),
                          hintText: 'e.g., 8.5',
                        ),
                      ),
                      const SizedBox(height: 12),
                      TextFormField(
                        controller: _notesCtrl,
                        maxLines: 2,
                        decoration: const InputDecoration(
                          labelText: 'Notes (optional)',
                          prefixIcon: Icon(Icons.notes),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),

              // Submit
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _isSubmitting ? null : _submit,
                  icon: _isSubmitting
                      ? const SizedBox(width: 18, height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Icon(Icons.save),
                  label: Text(_isSubmitting ? 'Saving...' : 'Save Production Data'),
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16)),
                ),
              ),
              const SizedBox(height: 8),
              const Center(
                child: Text(
                  '⚡ Dashboard will update in real-time',
                  style: TextStyle(color: Colors.grey, fontSize: 12),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
