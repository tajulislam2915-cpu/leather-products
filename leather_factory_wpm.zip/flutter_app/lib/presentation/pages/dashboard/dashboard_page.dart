// lib/presentation/pages/dashboard/dashboard_page.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:intl/intl.dart';
import '../../providers/app_providers.dart';
import '../../../core/constants/app_theme.dart';

class DashboardPage extends ConsumerStatefulWidget {
  const DashboardPage({super.key});

  @override
  ConsumerState<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends ConsumerState<DashboardPage> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadData());
  }

  void _loadData() {
    final factoryId = ref.read(authProvider).user?['factory_id'];
    if (factoryId != null) {
      ref.read(dashboardProvider.notifier).refresh(factoryId);
    }
  }

  @override
  Widget build(BuildContext context) {
    final dashboard = ref.watch(dashboardProvider);
    final auth = ref.watch(authProvider);
    final theme = Theme.of(context);
    final wsState = ref.watch(wsServiceProvider).state;
    final unread = ref.watch(unreadCountProvider);

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Dashboard', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
            Text(DateFormat('EEEE, d MMMM yyyy').format(DateTime.now()),
              style: const TextStyle(fontSize: 12, color: Colors.white70)),
          ],
        ),
        actions: [
          // WS indicator
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Icon(
              Icons.circle,
              size: 10,
              color: wsState == WsConnectionState.connected ? AppTheme.successColor : Colors.orange,
            ),
          ),
          // Notifications
          Stack(
            clipBehavior: Clip.none,
            children: [
              IconButton(
                icon: const Icon(Icons.notifications_outlined),
                onPressed: () {},
              ),
              if (unread > 0)
                Positioned(
                  right: 6, top: 6,
                  child: Container(
                    padding: const EdgeInsets.all(3),
                    decoration: const BoxDecoration(color: AppTheme.errorColor, shape: BoxShape.circle),
                    child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 9)),
                  ),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _loadData,
          ),
        ],
      ),
      body: dashboard.isLoading && dashboard.attendanceSummary == null
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async => _loadData(),
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Realtime badge
                    if (dashboard.lastUpdated != null)
                      Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: AppTheme.successColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: AppTheme.successColor.withOpacity(0.3)),
                        ),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          const Icon(Icons.sync, size: 14, color: AppTheme.successColor),
                          const SizedBox(width: 6),
                          Text(
                            'Live · Updated ${DateFormat('HH:mm:ss').format(dashboard.lastUpdated!)}',
                            style: const TextStyle(color: AppTheme.successColor, fontSize: 12, fontWeight: FontWeight.w500),
                          ),
                        ]),
                      ),

                    // Attendance Stats Row
                    _SectionTitle(title: 'Today\'s Attendance'),
                    const SizedBox(height: 8),
                    _AttendanceStatsRow(data: dashboard.attendanceSummary),
                    const SizedBox(height: 20),

                    // Production Stats
                    _SectionTitle(title: 'Production Overview'),
                    const SizedBox(height: 8),
                    _ProductionStatsRow(data: dashboard.productionSummary),
                    const SizedBox(height: 20),

                    // Attendance Donut Chart
                    if (dashboard.attendanceSummary != null) ...[
                      _SectionTitle(title: 'Attendance Breakdown'),
                      const SizedBox(height: 8),
                      _AttendanceChart(data: dashboard.attendanceSummary!),
                      const SizedBox(height: 20),
                    ],

                    // Leaderboard
                    _SectionTitle(title: '🏆 Top Performers Today'),
                    const SizedBox(height: 8),
                    _LeaderboardCard(entries: dashboard.leaderboard),
                    const SizedBox(height: 80),
                  ],
                ),
              ),
            ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(
      fontWeight: FontWeight.w700));
  }
}

class _AttendanceStatsRow extends StatelessWidget {
  final Map<String, dynamic>? data;
  const _AttendanceStatsRow({this.data});

  @override
  Widget build(BuildContext context) {
    final total = data?['total_workers'] ?? 0;
    final present = data?['present'] ?? 0;
    final absent = data?['absent'] ?? 0;
    final rate = (data?['attendance_rate'] ?? 0.0).toDouble();

    return Row(children: [
      Expanded(child: _StatCard(
        label: 'Total Workers', value: '$total',
        icon: Icons.people_outline, color: AppTheme.primaryColor)),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Present', value: '$present',
        icon: Icons.check_circle_outline, color: AppTheme.successColor)),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Absent', value: '$absent',
        icon: Icons.cancel_outlined, color: AppTheme.errorColor)),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Rate', value: '${rate.toStringAsFixed(1)}%',
        icon: Icons.trending_up, color: AppTheme.infoColor)),
    ]);
  }
}

class _ProductionStatsRow extends StatelessWidget {
  final Map<String, dynamic>? data;
  const _ProductionStatsRow({this.data});

  @override
  Widget build(BuildContext context) {
    final efficiency = (data?['avg_efficiency'] ?? 0.0).toDouble();
    final completed = data?['total_completed'] ?? 0;
    final target = data?['total_target'] ?? 0;
    final aboveTarget = data?['above_target_count'] ?? 0;

    return Row(children: [
      Expanded(child: _StatCard(
        label: 'Avg Efficiency', value: '${efficiency.toStringAsFixed(1)}%',
        icon: Icons.speed, color: efficiencyColor(efficiency))),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Completed', value: '$completed',
        icon: Icons.inventory_2_outlined, color: AppTheme.primaryColor)),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Target', value: '$target',
        icon: Icons.flag_outlined, color: AppTheme.warningColor)),
      const SizedBox(width: 10),
      Expanded(child: _StatCard(
        label: 'Above Target', value: '$aboveTarget',
        icon: Icons.emoji_events_outlined, color: AppTheme.successColor)),
    ]);
  }
}

class _StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  final Color color;
  const _StatCard({required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(height: 8),
            Text(value, style: TextStyle(
              fontSize: 22, fontWeight: FontWeight.w800, color: color)),
            const SizedBox(height: 2),
            Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey),
              maxLines: 1, overflow: TextOverflow.ellipsis),
          ],
        ),
      ),
    );
  }
}

class _AttendanceChart extends StatelessWidget {
  final Map<String, dynamic> data;
  const _AttendanceChart({required this.data});

  @override
  Widget build(BuildContext context) {
    final present = (data['present'] ?? 0).toDouble();
    final absent = (data['absent'] ?? 0).toDouble();
    final late = (data['late'] ?? 0).toDouble();
    final leave = (data['on_leave'] ?? 0).toDouble();

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            SizedBox(
              height: 200,
              child: PieChart(PieChartData(
                sectionsSpace: 3,
                centerSpaceRadius: 50,
                sections: [
                  PieChartSectionData(value: present, color: AppTheme.successColor,
                    title: '${present.toInt()}', titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  PieChartSectionData(value: absent, color: AppTheme.errorColor,
                    title: '${absent.toInt()}', titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  PieChartSectionData(value: late, color: AppTheme.warningColor,
                    title: '${late.toInt()}', titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                  if (leave > 0) PieChartSectionData(value: leave, color: AppTheme.infoColor,
                    title: '${leave.toInt()}', titleStyle: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                ],
              )),
            ),
            const SizedBox(height: 16),
            Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
              _ChartLegend(color: AppTheme.successColor, label: 'Present'),
              _ChartLegend(color: AppTheme.errorColor, label: 'Absent'),
              _ChartLegend(color: AppTheme.warningColor, label: 'Late'),
              _ChartLegend(color: AppTheme.infoColor, label: 'On Leave'),
            ]),
          ],
        ),
      ),
    );
  }
}

class _ChartLegend extends StatelessWidget {
  final Color color;
  final String label;
  const _ChartLegend({required this.color, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
      const SizedBox(width: 4),
      Text(label, style: const TextStyle(fontSize: 12)),
    ]);
  }
}

class _LeaderboardCard extends StatelessWidget {
  final List<Map<String, dynamic>> entries;
  const _LeaderboardCard({required this.entries});

  @override
  Widget build(BuildContext context) {
    if (entries.isEmpty) {
      return const Card(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Center(child: Text('No performance data yet today')),
        ),
      );
    }

    return Card(
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: entries.length > 10 ? 10 : entries.length,
        separatorBuilder: (_, __) => const Divider(height: 1),
        itemBuilder: (context, i) {
          final entry = entries[i];
          final worker = entry['worker'] as Map<String, dynamic>?;
          final rank = entry['rank'] ?? (i + 1);
          final score = (entry['total_score'] ?? 0.0).toDouble();
          final isBonus = entry['is_bonus_eligible'] == true;

          Color rankColor = Colors.grey;
          if (rank == 1) rankColor = const Color(0xFFFFD700);
          else if (rank == 2) rankColor = const Color(0xFFC0C0C0);
          else if (rank == 3) rankColor = const Color(0xFFCD7F32);

          return ListTile(
            dense: true,
            leading: CircleAvatar(
              radius: 18,
              backgroundColor: rankColor.withOpacity(0.15),
              child: Text('$rank', style: TextStyle(
                color: rankColor, fontWeight: FontWeight.w800, fontSize: 13)),
            ),
            title: Text(worker?['full_name'] ?? 'Worker $rank',
              style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
            subtitle: Text('EID: ${worker?['employee_id'] ?? '-'}',
              style: const TextStyle(fontSize: 12)),
            trailing: Row(mainAxisSize: MainAxisSize.min, children: [
              if (isBonus)
                const Padding(
                  padding: EdgeInsets.only(right: 6),
                  child: Icon(Icons.stars, color: AppTheme.secondaryColor, size: 18),
                ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: efficiencyColor(score).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text('${score.toStringAsFixed(1)}',
                  style: TextStyle(
                    color: efficiencyColor(score),
                    fontWeight: FontWeight.w700,
                    fontSize: 13,
                  )),
              ),
            ]),
          );
        },
      ),
    );
  }
}
