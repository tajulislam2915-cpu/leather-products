"""
Complete SQLAlchemy ORM Models for Leather Factory WPM System.
Implements all tables with proper relationships, constraints, and indexes.
"""
import uuid
from datetime import date, datetime, time
from decimal import Decimal
from enum import Enum as PyEnum
from typing import List, Optional

from sqlalchemy import (
    BigInteger, Boolean, CheckConstraint, Column, Date, DateTime,
    Enum, ForeignKey, Index, Integer, Numeric, String, Text, Time,
    UniqueConstraint, func, text,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB, ARRAY
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.db.database import Base


# ─── Enums ───────────────────────────────────────────────────────────────────
class UserRoleEnum(str, PyEnum):
    SUPER_ADMIN = "super_admin"
    FACTORY_ADMIN = "factory_admin"
    SUPERVISOR = "supervisor"
    WORKER = "worker"


class AttendanceStatusEnum(str, PyEnum):
    PRESENT = "present"
    ABSENT = "absent"
    LATE = "late"
    HALF_DAY = "half_day"
    ON_LEAVE = "on_leave"


class AttendanceMethodEnum(str, PyEnum):
    QR_CODE = "qr_code"
    RFID = "rfid"
    MANUAL = "manual"
    FACE_RECOGNITION = "face_recognition"


class GenderEnum(str, PyEnum):
    MALE = "male"
    FEMALE = "female"
    OTHER = "other"


class ShiftEnum(str, PyEnum):
    MORNING = "morning"    # 06:00 - 14:00
    AFTERNOON = "afternoon"  # 14:00 - 22:00
    NIGHT = "night"        # 22:00 - 06:00


class NotificationTypeEnum(str, PyEnum):
    ATTENDANCE_REMINDER = "attendance_reminder"
    TARGET_MISS = "target_miss"
    BONUS_ELIGIBLE = "bonus_eligible"
    PERFORMANCE_REPORT = "performance_report"
    SYSTEM = "system"


# ─── Mixin: Timestamps & UUID PK ─────────────────────────────────────────────
class UUIDMixin:
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4, index=True
    )


class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


class SoftDeleteMixin:
    is_deleted: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    deleted_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    deleted_by: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)


# ─── Factory ──────────────────────────────────────────────────────────────────
class Factory(UUIDMixin, TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "factories"

    name: Mapped[str] = mapped_column(String(200), nullable=False)
    code: Mapped[str] = mapped_column(String(20), nullable=False, unique=True)
    address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    city: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    country: Mapped[str] = mapped_column(String(100), nullable=False, default="Bangladesh")
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    logo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    timezone: Mapped[str] = mapped_column(String(50), default="Asia/Dhaka", nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    settings: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    # Relationships
    departments: Mapped[List["Department"]] = relationship(back_populates="factory", cascade="all, delete-orphan")
    users: Mapped[List["User"]] = relationship(back_populates="factory")
    production_lines: Mapped[List["ProductionLine"]] = relationship(back_populates="factory")

    __table_args__ = (
        Index("ix_factories_code", "code"),
        Index("ix_factories_is_active", "is_active"),
    )


# ─── Department ───────────────────────────────────────────────────────────────
class Department(UUIDMixin, TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "departments"

    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    code: Mapped[str] = mapped_column(String(20), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    manager_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    # Relationships
    factory: Mapped["Factory"] = relationship(back_populates="departments")
    workers: Mapped[List["User"]] = relationship(back_populates="department")
    production_lines: Mapped[List["ProductionLine"]] = relationship(back_populates="department")

    __table_args__ = (
        UniqueConstraint("factory_id", "code", name="uq_department_factory_code"),
        Index("ix_departments_factory_id", "factory_id"),
    )


# ─── Production Line ──────────────────────────────────────────────────────────
class ProductionLine(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "production_lines"

    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )
    department_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    code: Mapped[str] = mapped_column(String(20), nullable=False)
    capacity: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    # Relationships
    factory: Mapped["Factory"] = relationship(back_populates="production_lines")
    department: Mapped[Optional["Department"]] = relationship(back_populates="production_lines")
    production_records: Mapped[List["ProductionRecord"]] = relationship(back_populates="production_line")

    __table_args__ = (
        UniqueConstraint("factory_id", "code", name="uq_prodline_factory_code"),
        Index("ix_production_lines_factory_id", "factory_id"),
    )


# ─── Product Type ─────────────────────────────────────────────────────────────
class ProductType(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "product_types"

    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(200), nullable=False)
    code: Mapped[str] = mapped_column(String(20), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    default_daily_target: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    unit: Mapped[str] = mapped_column(String(50), default="pieces", nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)

    __table_args__ = (
        UniqueConstraint("factory_id", "code", name="uq_producttype_factory_code"),
    )


# ─── User (Workers, Supervisors, Admins) ──────────────────────────────────────
class User(UUIDMixin, TimestampMixin, SoftDeleteMixin, Base):
    __tablename__ = "users"

    factory_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="SET NULL"), nullable=True
    )
    department_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("departments.id", ondelete="SET NULL"), nullable=True
    )
    production_line_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("production_lines.id", ondelete="SET NULL"), nullable=True
    )

    # Auth
    email: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    role: Mapped[UserRoleEnum] = mapped_column(Enum(UserRoleEnum), nullable=False)

    # Personal Info
    employee_id: Mapped[str] = mapped_column(String(50), nullable=False, unique=True, index=True)
    first_name: Mapped[str] = mapped_column(String(100), nullable=False)
    last_name: Mapped[str] = mapped_column(String(100), nullable=False)
    gender: Mapped[Optional[GenderEnum]] = mapped_column(Enum(GenderEnum), nullable=True)
    date_of_birth: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    phone: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    address: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    profile_photo_url: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    face_encoding: Mapped[Optional[str]] = mapped_column(Text, nullable=True)  # JSON array

    # Work Info
    designation: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    shift: Mapped[Optional[ShiftEnum]] = mapped_column(Enum(ShiftEnum), nullable=True)
    join_date: Mapped[Optional[date]] = mapped_column(Date, nullable=True)
    daily_target: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    base_salary: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True)

    # RFID / QR
    rfid_card_number: Mapped[Optional[str]] = mapped_column(String(100), nullable=True, unique=True)
    qr_code: Mapped[Optional[str]] = mapped_column(String(500), nullable=True, unique=True)

    # Status
    is_active: Mapped[bool] = mapped_column(Boolean, default=True, nullable=False)
    is_verified: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    last_login: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    # Push Notifications
    fcm_token: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    # Relationships
    factory: Mapped[Optional["Factory"]] = relationship(back_populates="users")
    department: Mapped[Optional["Department"]] = relationship(back_populates="workers")
    production_line: Mapped[Optional["ProductionLine"]] = relationship()
    attendance_records: Mapped[List["AttendanceRecord"]] = relationship(
        back_populates="worker", foreign_keys="AttendanceRecord.worker_id"
    )
    production_records: Mapped[List["ProductionRecord"]] = relationship(
        back_populates="worker", foreign_keys="ProductionRecord.worker_id"
    )
    quality_records: Mapped[List["QualityRecord"]] = relationship(
        back_populates="worker", foreign_keys="QualityRecord.worker_id"
    )
    performance_scores: Mapped[List["PerformanceScore"]] = relationship(back_populates="worker")
    refresh_tokens: Mapped[List["RefreshToken"]] = relationship(back_populates="user", cascade="all, delete-orphan")
    notifications: Mapped[List["Notification"]] = relationship(back_populates="recipient")

    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"

    __table_args__ = (
        Index("ix_users_factory_id", "factory_id"),
        Index("ix_users_department_id", "department_id"),
        Index("ix_users_role", "role"),
        Index("ix_users_is_active", "is_active"),
        Index("ix_users_rfid", "rfid_card_number"),
    )


# ─── Refresh Token ────────────────────────────────────────────────────────────
class RefreshToken(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "refresh_tokens"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    token_hash: Mapped[str] = mapped_column(String(255), nullable=False, unique=True, index=True)
    expires_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), nullable=False)
    is_revoked: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    device_info: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    user: Mapped["User"] = relationship(back_populates="refresh_tokens")

    __table_args__ = (
        Index("ix_refresh_tokens_user_id", "user_id"),
    )


# ─── Attendance Record ────────────────────────────────────────────────────────
class AttendanceRecord(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "attendance_records"

    worker_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    recorded_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )

    date: Mapped[date] = mapped_column(Date, nullable=False)
    check_in_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    check_out_time: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    status: Mapped[AttendanceStatusEnum] = mapped_column(
        Enum(AttendanceStatusEnum), nullable=False, default=AttendanceStatusEnum.ABSENT
    )
    method: Mapped[AttendanceMethodEnum] = mapped_column(
        Enum(AttendanceMethodEnum), nullable=False, default=AttendanceMethodEnum.MANUAL
    )
    shift: Mapped[Optional[ShiftEnum]] = mapped_column(Enum(ShiftEnum), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    overtime_hours: Mapped[Decimal] = mapped_column(Numeric(4, 2), default=0, nullable=False)

    # Relationships
    worker: Mapped["User"] = relationship(back_populates="attendance_records", foreign_keys=[worker_id])
    supervisor: Mapped[Optional["User"]] = relationship(foreign_keys=[recorded_by])

    __table_args__ = (
        UniqueConstraint("worker_id", "date", name="uq_attendance_worker_date"),
        Index("ix_attendance_worker_id", "worker_id"),
        Index("ix_attendance_date", "date"),
        Index("ix_attendance_factory_date", "factory_id", "date"),
        Index("ix_attendance_status", "status"),
    )


# ─── Production Record ────────────────────────────────────────────────────────
class ProductionRecord(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "production_records"

    worker_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    supervisor_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
    )
    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )
    production_line_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("production_lines.id", ondelete="SET NULL"), nullable=True
    )
    product_type_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("product_types.id", ondelete="SET NULL"), nullable=True
    )

    date: Mapped[date] = mapped_column(Date, nullable=False)
    shift: Mapped[Optional[ShiftEnum]] = mapped_column(Enum(ShiftEnum), nullable=True)

    daily_target: Mapped[int] = mapped_column(Integer, nullable=False)
    completed_quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    efficiency: Mapped[Decimal] = mapped_column(
        Numeric(6, 2), nullable=False, default=0
    )  # Computed: completed/target * 100

    working_hours: Mapped[Optional[Decimal]] = mapped_column(Numeric(4, 2), nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    worker: Mapped["User"] = relationship(back_populates="production_records", foreign_keys=[worker_id])
    supervisor: Mapped["User"] = relationship(foreign_keys=[supervisor_id])
    production_line: Mapped[Optional["ProductionLine"]] = relationship(back_populates="production_records")
    quality_records: Mapped[List["QualityRecord"]] = relationship(back_populates="production_record")

    __table_args__ = (
        UniqueConstraint("worker_id", "date", "shift", name="uq_production_worker_date_shift"),
        CheckConstraint("completed_quantity >= 0", name="ck_production_completed_nonneg"),
        CheckConstraint("daily_target > 0", name="ck_production_target_positive"),
        CheckConstraint("efficiency >= 0 AND efficiency <= 999", name="ck_production_efficiency_range"),
        Index("ix_production_worker_id", "worker_id"),
        Index("ix_production_date", "date"),
        Index("ix_production_factory_date", "factory_id", "date"),
        Index("ix_production_line_date", "production_line_id", "date"),
    )


# ─── Quality Record ───────────────────────────────────────────────────────────
class QualityRecord(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "quality_records"

    production_record_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("production_records.id", ondelete="CASCADE"), nullable=False
    )
    worker_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    supervisor_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
    )
    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )

    date: Mapped[date] = mapped_column(Date, nullable=False)
    produced_quantity: Mapped[int] = mapped_column(Integer, nullable=False)
    defective_quantity: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    quality_score: Mapped[Decimal] = mapped_column(
        Numeric(6, 2), nullable=False
    )  # (produced - defective) / produced * 100

    defect_categories: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    notes: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    # Relationships
    production_record: Mapped["ProductionRecord"] = relationship(back_populates="quality_records")
    worker: Mapped["User"] = relationship(back_populates="quality_records", foreign_keys=[worker_id])
    supervisor: Mapped["User"] = relationship(foreign_keys=[supervisor_id])

    __table_args__ = (
        CheckConstraint("defective_quantity >= 0", name="ck_quality_defective_nonneg"),
        CheckConstraint("produced_quantity > 0", name="ck_quality_produced_positive"),
        CheckConstraint("defective_quantity <= produced_quantity", name="ck_quality_defective_lte_produced"),
        CheckConstraint("quality_score >= 0 AND quality_score <= 100", name="ck_quality_score_range"),
        Index("ix_quality_worker_id", "worker_id"),
        Index("ix_quality_date", "date"),
        Index("ix_quality_factory_date", "factory_id", "date"),
    )


# ─── Performance Score ────────────────────────────────────────────────────────
class PerformanceScore(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "performance_scores"

    worker_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    factory_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=False
    )

    score_date: Mapped[date] = mapped_column(Date, nullable=False)
    period_type: Mapped[str] = mapped_column(
        String(20), nullable=False
    )  # 'daily' | 'weekly' | 'monthly'
    period_start: Mapped[date] = mapped_column(Date, nullable=False)
    period_end: Mapped[date] = mapped_column(Date, nullable=False)

    # Component scores (0-100)
    efficiency_score: Mapped[Decimal] = mapped_column(Numeric(6, 2), nullable=False, default=0)
    quality_score: Mapped[Decimal] = mapped_column(Numeric(6, 2), nullable=False, default=0)
    attendance_score: Mapped[Decimal] = mapped_column(Numeric(6, 2), nullable=False, default=0)

    # Weighted total score
    total_score: Mapped[Decimal] = mapped_column(Numeric(6, 2), nullable=False, default=0)

    # Ranking
    rank: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    total_workers: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)

    # Bonus
    is_bonus_eligible: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    bonus_amount: Mapped[Optional[Decimal]] = mapped_column(Numeric(12, 2), nullable=True)

    # Relationships
    worker: Mapped["User"] = relationship(back_populates="performance_scores")

    __table_args__ = (
        UniqueConstraint("worker_id", "period_type", "period_start", name="uq_perf_worker_period"),
        Index("ix_perf_worker_id", "worker_id"),
        Index("ix_perf_score_date", "score_date"),
        Index("ix_perf_period_type", "period_type"),
        Index("ix_perf_factory_period", "factory_id", "period_type", "period_start"),
        Index("ix_perf_total_score", "total_score"),
    )


# ─── Notification ─────────────────────────────────────────────────────────────
class Notification(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "notifications"

    recipient_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    factory_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("factories.id", ondelete="CASCADE"), nullable=True
    )

    type: Mapped[NotificationTypeEnum] = mapped_column(Enum(NotificationTypeEnum), nullable=False)
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    body: Mapped[str] = mapped_column(Text, nullable=False)
    data: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)

    is_read: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    sent_via_push: Mapped[bool] = mapped_column(Boolean, default=False, nullable=False)

    recipient: Mapped["User"] = relationship(back_populates="notifications")

    __table_args__ = (
        Index("ix_notifications_recipient_id", "recipient_id"),
        Index("ix_notifications_is_read", "is_read"),
        Index("ix_notifications_created_at", "created_at"),
    )


# ─── Audit Log ────────────────────────────────────────────────────────────────
class AuditLog(UUIDMixin, Base):
    __tablename__ = "audit_logs"

    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    factory_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)

    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )
    action: Mapped[str] = mapped_column(String(100), nullable=False)  # CREATE, UPDATE, DELETE
    resource: Mapped[str] = mapped_column(String(100), nullable=False)  # Table name
    resource_id: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    old_values: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    new_values: Mapped[Optional[dict]] = mapped_column(JSONB, nullable=True)
    ip_address: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    user_agent: Mapped[Optional[str]] = mapped_column(String(500), nullable=True)

    __table_args__ = (
        Index("ix_audit_user_id", "user_id"),
        Index("ix_audit_resource", "resource"),
        Index("ix_audit_timestamp", "timestamp"),
    )


# ─── Worker Transfer History ──────────────────────────────────────────────────
class WorkerTransfer(UUIDMixin, TimestampMixin, Base):
    __tablename__ = "worker_transfers"

    worker_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    transferred_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=False
    )

    from_department_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    to_department_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    from_production_line_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    to_production_line_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    from_factory_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)
    to_factory_id: Mapped[Optional[uuid.UUID]] = mapped_column(UUID(as_uuid=True), nullable=True)

    effective_date: Mapped[date] = mapped_column(Date, nullable=False)
    reason: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    __table_args__ = (
        Index("ix_transfer_worker_id", "worker_id"),
        Index("ix_transfer_effective_date", "effective_date"),
    )
