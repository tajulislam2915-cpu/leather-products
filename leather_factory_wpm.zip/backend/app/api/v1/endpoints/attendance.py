"""
Attendance API endpoints - QR, RFID, Manual, Face Recognition.
"""
import base64
import io
from datetime import date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user, require_supervisor, get_db
from app.models.models import AttendanceRecord, User, AttendanceStatusEnum
from app.schemas.schemas import (
    AttendanceCreate, AttendanceResponse, AttendanceSummary, AttendanceUpdate,
    QRAttendanceRequest, RFIDAttendanceRequest,
)
from app.services.performance_service import RealtimeBroadcastService
from app.websocket.manager import ws_manager, WSEvent

router = APIRouter(prefix="/attendance", tags=["Attendance"])


@router.post("/", response_model=AttendanceResponse, status_code=status.HTTP_201_CREATED)
async def mark_attendance(
    payload: AttendanceCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Manual attendance marking by supervisor."""
    # Upsert: if record exists for worker+date, update it
    stmt = select(AttendanceRecord).where(
        and_(
            AttendanceRecord.worker_id == payload.worker_id,
            AttendanceRecord.date == payload.date,
        )
    )
    result = await db.execute(stmt)
    existing = result.scalar_one_or_none()

    if existing:
        existing.status = payload.status
        existing.method = payload.method
        if payload.check_in_time:
            existing.check_in_time = payload.check_in_time
        if payload.check_out_time:
            existing.check_out_time = payload.check_out_time
        existing.notes = payload.notes
        existing.overtime_hours = payload.overtime_hours
        existing.recorded_by = current_user.id
        await db.commit()
        await db.refresh(existing)
        record = existing
    else:
        # Get factory_id from worker
        worker_stmt = select(User).where(User.id == payload.worker_id)
        worker_result = await db.execute(worker_stmt)
        worker = worker_result.scalar_one_or_none()
        if not worker:
            raise HTTPException(status_code=404, detail="Worker not found")

        record = AttendanceRecord(
            worker_id=payload.worker_id,
            recorded_by=current_user.id,
            factory_id=worker.factory_id,
            date=payload.date,
            status=payload.status,
            method=payload.method,
            check_in_time=payload.check_in_time,
            check_out_time=payload.check_out_time,
            shift=payload.shift,
            notes=payload.notes,
            overtime_hours=payload.overtime_hours,
        )
        db.add(record)
        await db.commit()
        await db.refresh(record)

    # Broadcast realtime
    background_tasks.add_task(
        _broadcast_attendance,
        factory_id=str(record.factory_id),
        attendance_data={
            "id": str(record.id),
            "worker_id": str(record.worker_id),
            "date": record.date.isoformat(),
            "status": record.status.value if hasattr(record.status, 'value') else record.status,
            "method": record.method.value if hasattr(record.method, 'value') else record.method,
        },
    )

    return AttendanceResponse.model_validate(record)


@router.post("/qr-scan", response_model=AttendanceResponse)
async def qr_attendance(
    payload: QRAttendanceRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """Process QR code scan for attendance."""
    stmt = select(User).where(User.qr_code == payload.qr_code, User.is_active == True)
    result = await db.execute(stmt)
    worker = result.scalar_one_or_none()

    if not worker:
        raise HTTPException(status_code=404, detail="Invalid QR code or inactive worker")

    scan_date = payload.date or date.today()

    existing_stmt = select(AttendanceRecord).where(
        and_(AttendanceRecord.worker_id == worker.id, AttendanceRecord.date == scan_date)
    )
    existing_result = await db.execute(existing_stmt)
    existing = existing_result.scalar_one_or_none()

    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)

    if payload.action == "check_in":
        if existing and existing.check_in_time:
            raise HTTPException(status_code=409, detail="Already checked in today")
        if existing:
            existing.check_in_time = now
            existing.status = AttendanceStatusEnum.PRESENT
            existing.method = "qr_code"
            await db.commit()
            await db.refresh(existing)
            record = existing
        else:
            record = AttendanceRecord(
                worker_id=worker.id,
                factory_id=payload.factory_id,
                date=scan_date,
                check_in_time=now,
                status=AttendanceStatusEnum.PRESENT,
                method="qr_code",
            )
            db.add(record)
            await db.commit()
            await db.refresh(record)
    else:  # check_out
        if not existing:
            raise HTTPException(status_code=400, detail="No check-in found. Cannot check-out.")
        existing.check_out_time = now
        await db.commit()
        await db.refresh(existing)
        record = existing

    background_tasks.add_task(
        _broadcast_attendance,
        factory_id=str(payload.factory_id),
        attendance_data={"worker_id": str(worker.id), "action": payload.action, "timestamp": now.isoformat()},
    )

    return AttendanceResponse.model_validate(record)


@router.post("/rfid-scan", response_model=AttendanceResponse)
async def rfid_attendance(
    payload: RFIDAttendanceRequest,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
):
    """Process RFID card swipe for attendance."""
    stmt = select(User).where(User.rfid_card_number == payload.rfid_card, User.is_active == True)
    result = await db.execute(stmt)
    worker = result.scalar_one_or_none()

    if not worker:
        raise HTTPException(status_code=404, detail="RFID card not registered or worker inactive")

    today = date.today()
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)

    existing_stmt = select(AttendanceRecord).where(
        and_(AttendanceRecord.worker_id == worker.id, AttendanceRecord.date == today)
    )
    existing_result = await db.execute(existing_stmt)
    existing = existing_result.scalar_one_or_none()

    if payload.action == "check_in":
        if not existing:
            record = AttendanceRecord(
                worker_id=worker.id,
                factory_id=payload.factory_id,
                date=today,
                check_in_time=now,
                status=AttendanceStatusEnum.PRESENT,
                method="rfid",
            )
            db.add(record)
        else:
            existing.check_in_time = now
            existing.method = "rfid"
            record = existing
    else:
        if existing:
            existing.check_out_time = now
            record = existing
        else:
            raise HTTPException(status_code=400, detail="No check-in found")

    await db.commit()
    await db.refresh(record)

    background_tasks.add_task(
        _broadcast_attendance,
        factory_id=str(payload.factory_id),
        attendance_data={"worker_id": str(worker.id), "action": payload.action},
    )

    return AttendanceResponse.model_validate(record)


@router.get("/summary", response_model=AttendanceSummary)
async def get_attendance_summary(
    factory_id: UUID = Query(...),
    target_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Daily attendance summary for dashboard."""
    if target_date is None:
        target_date = date.today()

    # Total active workers
    worker_count_stmt = select(func.count(User.id)).where(
        User.factory_id == factory_id,
        User.role == "worker",
        User.is_active == True,
    )
    total_result = await db.execute(worker_count_stmt)
    total_workers = total_result.scalar() or 0

    # Attendance counts by status
    stmt = select(
        AttendanceRecord.status,
        func.count(AttendanceRecord.id).label("count"),
    ).where(
        and_(
            AttendanceRecord.factory_id == factory_id,
            AttendanceRecord.date == target_date,
        )
    ).group_by(AttendanceRecord.status)

    result = await db.execute(stmt)
    counts = {row.status: row.count for row in result}

    present = counts.get(AttendanceStatusEnum.PRESENT, 0) + counts.get(AttendanceStatusEnum.LATE, 0)
    absent = total_workers - present - counts.get(AttendanceStatusEnum.ON_LEAVE, 0)

    return AttendanceSummary(
        factory_id=factory_id,
        date=target_date,
        total_workers=total_workers,
        present=present,
        absent=max(0, absent),
        late=counts.get(AttendanceStatusEnum.LATE, 0),
        half_day=counts.get(AttendanceStatusEnum.HALF_DAY, 0),
        on_leave=counts.get(AttendanceStatusEnum.ON_LEAVE, 0),
        attendance_rate=round(present / total_workers * 100, 2) if total_workers > 0 else 0.0,
    )


@router.get("/", response_model=List[AttendanceResponse])
async def list_attendance(
    factory_id: UUID = Query(...),
    target_date: Optional[date] = Query(None),
    worker_id: Optional[UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    filters = [AttendanceRecord.factory_id == factory_id]
    if target_date:
        filters.append(AttendanceRecord.date == target_date)
    if worker_id:
        if current_user.role.value == "worker" and current_user.id != worker_id:
            raise HTTPException(status_code=403, detail="Access denied")
        filters.append(AttendanceRecord.worker_id == worker_id)
    elif current_user.role.value == "worker":
        filters.append(AttendanceRecord.worker_id == current_user.id)

    stmt = select(AttendanceRecord).where(and_(*filters)).order_by(AttendanceRecord.date.desc())
    result = await db.execute(stmt)
    records = result.scalars().all()

    return [AttendanceResponse.model_validate(r) for r in records]


async def _broadcast_attendance(factory_id: str, attendance_data: dict):
    await ws_manager.broadcast_to_factory(factory_id, WSEvent.ATTENDANCE_MARKED, attendance_data)
