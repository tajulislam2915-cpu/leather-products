"""
Reports module: PDF, Excel, CSV generation with filters.
Uses ReportLab for PDF, OpenPyXL for Excel.
"""
import io
import csv
from datetime import date
from typing import Optional
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from sqlalchemy import and_, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db, require_supervisor
from app.models.models import (
    AttendanceRecord, PerformanceScore, ProductionRecord, QualityRecord, User
)

router = APIRouter(prefix="/reports", tags=["Reports"])


@router.get("/attendance")
async def export_attendance_report(
    factory_id: UUID = Query(...),
    start_date: date = Query(...),
    end_date: date = Query(...),
    format: str = Query(default="pdf", pattern="^(pdf|excel|csv)$"),
    department_id: Optional[UUID] = Query(None),
    worker_id: Optional[UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Generate attendance report in PDF/Excel/CSV."""
    filters = [
        AttendanceRecord.factory_id == factory_id,
        AttendanceRecord.date >= start_date,
        AttendanceRecord.date <= end_date,
    ]
    if worker_id:
        filters.append(AttendanceRecord.worker_id == worker_id)

    stmt = (
        select(AttendanceRecord, User)
        .join(User, AttendanceRecord.worker_id == User.id)
        .where(and_(*filters))
        .order_by(AttendanceRecord.date, User.first_name)
    )
    result = await db.execute(stmt)
    rows = result.all()

    data = []
    for rec, user in rows:
        data.append({
            "Employee ID": user.employee_id,
            "Name": f"{user.first_name} {user.last_name}",
            "Date": rec.date.strftime("%Y-%m-%d"),
            "Status": rec.status.value if hasattr(rec.status, 'value') else rec.status,
            "Method": rec.method.value if hasattr(rec.method, 'value') else rec.method,
            "Check In": rec.check_in_time.strftime("%H:%M") if rec.check_in_time else "-",
            "Check Out": rec.check_out_time.strftime("%H:%M") if rec.check_out_time else "-",
            "Overtime Hrs": float(rec.overtime_hours),
        })

    if format == "csv":
        return _generate_csv(data, "attendance_report")
    elif format == "excel":
        return await _generate_excel(data, "Attendance Report", start_date, end_date)
    else:
        return await _generate_pdf_attendance(data, start_date, end_date, factory_id)


@router.get("/production")
async def export_production_report(
    factory_id: UUID = Query(...),
    start_date: date = Query(...),
    end_date: date = Query(...),
    format: str = Query(default="pdf", pattern="^(pdf|excel|csv)$"),
    worker_id: Optional[UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Generate production efficiency report."""
    filters = [
        ProductionRecord.factory_id == factory_id,
        ProductionRecord.date >= start_date,
        ProductionRecord.date <= end_date,
    ]
    if worker_id:
        filters.append(ProductionRecord.worker_id == worker_id)

    stmt = (
        select(ProductionRecord, User)
        .join(User, ProductionRecord.worker_id == User.id)
        .where(and_(*filters))
        .order_by(ProductionRecord.date, User.first_name)
    )
    result = await db.execute(stmt)
    rows = result.all()

    data = []
    for rec, user in rows:
        data.append({
            "Employee ID": user.employee_id,
            "Name": f"{user.first_name} {user.last_name}",
            "Date": rec.date.strftime("%Y-%m-%d"),
            "Target": rec.daily_target,
            "Completed": rec.completed_quantity,
            "Efficiency %": float(rec.efficiency),
            "Working Hours": float(rec.working_hours) if rec.working_hours else "-",
        })

    if format == "csv":
        return _generate_csv(data, "production_report")
    elif format == "excel":
        return await _generate_excel(data, "Production Report", start_date, end_date)
    else:
        return await _generate_pdf_production(data, start_date, end_date)


@router.get("/performance")
async def export_performance_report(
    factory_id: UUID = Query(...),
    period_type: str = Query(default="monthly", pattern="^(daily|weekly|monthly)$"),
    start_date: date = Query(...),
    format: str = Query(default="pdf", pattern="^(pdf|excel|csv)$"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Generate performance leaderboard report."""
    stmt = (
        select(PerformanceScore, User)
        .join(User, PerformanceScore.worker_id == User.id)
        .where(
            and_(
                PerformanceScore.factory_id == factory_id,
                PerformanceScore.period_type == period_type,
                PerformanceScore.period_start == start_date,
            )
        )
        .order_by(PerformanceScore.total_score.desc())
    )
    result = await db.execute(stmt)
    rows = result.all()

    data = []
    for rank, (score, user) in enumerate(rows, start=1):
        data.append({
            "Rank": rank,
            "Employee ID": user.employee_id,
            "Name": f"{user.first_name} {user.last_name}",
            "Efficiency Score": float(score.efficiency_score),
            "Quality Score": float(score.quality_score),
            "Attendance Score": float(score.attendance_score),
            "Total Score": float(score.total_score),
            "Bonus Eligible": "Yes" if score.is_bonus_eligible else "No",
        })

    if format == "csv":
        return _generate_csv(data, "performance_report")
    elif format == "excel":
        return await _generate_excel(data, "Performance Report", start_date, start_date)
    else:
        return await _generate_pdf_performance(data, period_type, start_date, factory_id)


# ─── CSV Generator ────────────────────────────────────────────────────────────
def _generate_csv(data: list, filename: str) -> StreamingResponse:
    if not data:
        raise HTTPException(status_code=404, detail="No data for selected filters")

    output = io.StringIO()
    writer = csv.DictWriter(output, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)

    output.seek(0)
    return StreamingResponse(
        io.BytesIO(output.getvalue().encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{filename}.csv"'},
    )


# ─── Excel Generator ──────────────────────────────────────────────────────────
async def _generate_excel(data: list, title: str, start: date, end: date) -> StreamingResponse:
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = title[:31]  # Excel sheet name limit

        # Title row
        ws.merge_cells("A1:H1")
        ws["A1"] = f"{title} | {start} to {end}"
        ws["A1"].font = Font(bold=True, size=14)
        ws["A1"].alignment = Alignment(horizontal="center")

        if not data:
            ws["A3"] = "No data available"
        else:
            # Headers
            headers = list(data[0].keys())
            header_fill = PatternFill("solid", fgColor="2E3A4B")
            for col, header in enumerate(headers, start=1):
                cell = ws.cell(row=3, column=col, value=header)
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal="center")

            # Data rows
            for row_idx, row in enumerate(data, start=4):
                for col_idx, value in enumerate(row.values(), start=1):
                    cell = ws.cell(row=row_idx, column=col_idx, value=value)
                    if row_idx % 2 == 0:
                        cell.fill = PatternFill("solid", fgColor="F5F5F5")

            # Auto-fit columns
            for col in ws.columns:
                max_len = max(len(str(cell.value or "")) for cell in col)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 4, 40)

        output = io.BytesIO()
        wb.save(output)
        output.seek(0)

        return StreamingResponse(
            output,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": f'attachment; filename="{title.replace(" ", "_")}.xlsx"'},
        )
    except ImportError:
        raise HTTPException(status_code=500, detail="Excel generation not available")


# ─── PDF Generators ───────────────────────────────────────────────────────────
async def _generate_pdf_attendance(data: list, start: date, end: date, factory_id) -> StreamingResponse:
    return await _generate_pdf_generic(data, "Attendance Report", start, end)


async def _generate_pdf_production(data: list, start: date, end: date) -> StreamingResponse:
    return await _generate_pdf_generic(data, "Production Report", start, end)


async def _generate_pdf_performance(data: list, period: str, start: date, factory_id) -> StreamingResponse:
    return await _generate_pdf_generic(data, f"Performance Report ({period.title()})", start, start)


async def _generate_pdf_generic(data: list, title: str, start: date, end: date) -> StreamingResponse:
    try:
        from reportlab.lib import colors
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import inch
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer

        output = io.BytesIO()
        doc = SimpleDocTemplate(output, pagesize=landscape(A4), topMargin=0.5*inch, bottomMargin=0.5*inch)

        styles = getSampleStyleSheet()
        elements = []

        # Title
        elements.append(Paragraph(f"<b>{title}</b>", styles["Title"]))
        elements.append(Paragraph(f"Period: {start} to {end}", styles["Normal"]))
        elements.append(Spacer(1, 0.2*inch))

        if not data:
            elements.append(Paragraph("No data available for the selected filters.", styles["Normal"]))
        else:
            # Build table
            headers = list(data[0].keys())
            table_data = [headers] + [[str(row.get(h, "")) for h in headers] for row in data]

            col_width = (landscape(A4)[0] - inch) / len(headers)
            table = Table(table_data, colWidths=[col_width] * len(headers))
            table.setStyle(TableStyle([
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#2E3A4B")),
                ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                ("FONTSIZE", (0, 0), (-1, 0), 9),
                ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F5F7FA")]),
                ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#DDDDDD")),
                ("FONTSIZE", (0, 1), (-1, -1), 8),
                ("PADDING", (0, 0), (-1, -1), 4),
            ]))
            elements.append(table)

        doc.build(elements)
        output.seek(0)

        return StreamingResponse(
            output,
            media_type="application/pdf",
            headers={"Content-Disposition": f'attachment; filename="{title.replace(" ", "_")}.pdf"'},
        )
    except ImportError:
        raise HTTPException(status_code=500, detail="PDF generation not available")
