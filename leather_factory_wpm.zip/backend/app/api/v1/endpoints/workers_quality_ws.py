"""
Workers management, Quality records, Leaderboard, Dashboard, WebSocket endpoint.
"""
import asyncio
import base64
import io
from datetime import date, datetime, timezone
from typing import List, Optional
from uuid import UUID

import qrcode
from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import (
    get_current_user, get_db, get_ws_user, require_factory_admin,
    require_supervisor, PaginationParams,
)
from app.core.security import get_password_hash
from app.models.models import (
    PerformanceScore, QualityRecord, User, WorkerTransfer,
)
from app.schemas.schemas import (
    LeaderboardEntry, LeaderboardResponse, QRCodeResponse, QualityCreate,
    QualityResponse, UserBrief, UserCreate, UserResponse, UserUpdate,
    WorkerTransferRequest,
)
from app.services.performance_service import RealtimeBroadcastService
from app.websocket.manager import WSEvent, ws_manager

# ─── Workers Router ───────────────────────────────────────────────────────────
workers_router = APIRouter(prefix="/workers", tags=["Workers"])


@workers_router.post("/", response_model=UserResponse, status_code=201)
async def create_worker(
    payload: UserCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_factory_admin),
):
    """Create a new worker/supervisor account."""
    # Check email uniqueness
    stmt = select(User).where(User.email == payload.email)
    result = await db.execute(stmt)
    if result.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Email already registered")

    # Check employee ID uniqueness
    emp_stmt = select(User).where(User.employee_id == payload.employee_id)
    emp_result = await db.execute(emp_stmt)
    if emp_result.scalar_one_or_none():
        raise HTTPException(status_code=409, detail="Employee ID already exists")

    user = User(
        email=payload.email,
        hashed_password=get_password_hash(payload.password),
        role=payload.role,
        factory_id=payload.factory_id,
        department_id=payload.department_id,
        production_line_id=payload.production_line_id,
        employee_id=payload.employee_id,
        first_name=payload.first_name,
        last_name=payload.last_name,
        gender=payload.gender,
        date_of_birth=payload.date_of_birth,
        phone=payload.phone,
        address=payload.address,
        designation=payload.designation,
        shift=payload.shift,
        join_date=payload.join_date,
        daily_target=payload.daily_target,
        base_salary=payload.base_salary,
        rfid_card_number=payload.rfid_card_number,
    )
    db.add(user)
    await db.commit()
    await db.refresh(user)
    return UserResponse.model_validate(user)


@workers_router.get("/", response_model=List[UserResponse])
async def list_workers(
    factory_id: UUID = Query(...),
    department_id: Optional[UUID] = Query(None),
    role: Optional[str] = Query(None),
    is_active: bool = Query(True),
    search: Optional[str] = Query(None),
    pagination: PaginationParams = Depends(),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """List workers with filters."""
    filters = [User.factory_id == factory_id, User.is_deleted == False, User.is_active == is_active]
    if department_id:
        filters.append(User.department_id == department_id)
    if role:
        filters.append(User.role == role)
    if search:
        search_term = f"%{search}%"
        from sqlalchemy import or_
        filters.append(or_(
            User.first_name.ilike(search_term),
            User.last_name.ilike(search_term),
            User.employee_id.ilike(search_term),
        ))

    stmt = (
        select(User)
        .where(and_(*filters))
        .order_by(User.first_name)
        .offset(pagination.offset)
        .limit(pagination.size)
    )
    result = await db.execute(stmt)
    users = result.scalars().all()
    return [UserResponse.model_validate(u) for u in users]


@workers_router.get("/{worker_id}", response_model=UserResponse)
async def get_worker(
    worker_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role.value == "worker" and current_user.id != worker_id:
        raise HTTPException(status_code=403, detail="Access denied")

    stmt = select(User).where(User.id == worker_id, User.is_deleted == False)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Worker not found")
    return UserResponse.model_validate(user)


@workers_router.patch("/{worker_id}", response_model=UserResponse)
async def update_worker(
    worker_id: UUID,
    payload: UserUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_factory_admin),
):
    stmt = select(User).where(User.id == worker_id, User.is_deleted == False)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Worker not found")

    for field, value in payload.model_dump(exclude_none=True).items():
        setattr(user, field, value)

    await db.commit()
    await db.refresh(user)
    return UserResponse.model_validate(user)


@workers_router.delete("/{worker_id}")
async def delete_worker(
    worker_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_factory_admin),
):
    stmt = select(User).where(User.id == worker_id, User.is_deleted == False)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Worker not found")

    user.is_deleted = True
    user.deleted_at = datetime.now(timezone.utc)
    user.deleted_by = current_user.id
    user.is_active = False
    await db.commit()
    return {"message": "Worker deleted successfully"}


@workers_router.post("/{worker_id}/transfer")
async def transfer_worker(
    worker_id: UUID,
    payload: WorkerTransferRequest,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_factory_admin),
):
    """Transfer worker to different department/line/factory."""
    stmt = select(User).where(User.id == worker_id, User.is_deleted == False)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Worker not found")

    # Log transfer
    transfer = WorkerTransfer(
        worker_id=worker_id,
        transferred_by=current_user.id,
        from_department_id=user.department_id,
        to_department_id=payload.to_department_id,
        from_production_line_id=user.production_line_id,
        to_production_line_id=payload.to_production_line_id,
        from_factory_id=user.factory_id,
        to_factory_id=payload.to_factory_id,
        effective_date=payload.effective_date,
        reason=payload.reason,
    )
    db.add(transfer)

    # Apply transfer
    if payload.to_department_id:
        user.department_id = payload.to_department_id
    if payload.to_production_line_id:
        user.production_line_id = payload.to_production_line_id
    if payload.to_factory_id:
        user.factory_id = payload.to_factory_id

    await db.commit()
    return {"message": "Worker transferred successfully"}


@workers_router.get("/{worker_id}/qr-code", response_model=QRCodeResponse)
async def get_worker_qr_code(
    worker_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Generate/retrieve QR code for worker attendance."""
    stmt = select(User).where(User.id == worker_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    if not user:
        raise HTTPException(status_code=404, detail="Worker not found")

    # Generate QR if not exists
    qr_data = user.qr_code
    if not qr_data:
        qr_data = f"WORKER:{user.employee_id}:{str(user.id)}"
        user.qr_code = qr_data
        await db.commit()

    # Generate QR image
    qr = qrcode.QRCode(version=1, box_size=10, border=4)
    qr.add_data(qr_data)
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    buffered = io.BytesIO()
    img.save(buffered, format="PNG")
    img_b64 = base64.b64encode(buffered.getvalue()).decode()

    return QRCodeResponse(
        worker_id=worker_id,
        employee_id=user.employee_id,
        qr_code_data=qr_data,
        qr_code_image_base64=img_b64,
    )


# ─── Quality Router ───────────────────────────────────────────────────────────
quality_router = APIRouter(prefix="/quality", tags=["Quality"])


@quality_router.post("/", response_model=QualityResponse, status_code=201)
async def create_quality_record(
    payload: QualityCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Supervisor enters quality check data."""
    quality_score = ((payload.produced_quantity - payload.defective_quantity) / payload.produced_quantity) * 100

    record = QualityRecord(
        production_record_id=payload.production_record_id,
        worker_id=payload.worker_id,
        supervisor_id=current_user.id,
        factory_id=payload.factory_id,
        date=payload.date,
        produced_quantity=payload.produced_quantity,
        defective_quantity=payload.defective_quantity,
        quality_score=round(quality_score, 2),
        defect_categories=payload.defect_categories,
        notes=payload.notes,
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)

    quality_dict = {
        "id": str(record.id),
        "worker_id": str(record.worker_id),
        "quality_score": float(record.quality_score),
        "defective_quantity": record.defective_quantity,
    }

    background_tasks.add_task(
        _trigger_quality_update,
        factory_id=str(payload.factory_id),
        quality_data=quality_dict,
        worker_id=payload.worker_id,
        db=db,
    )

    return QualityResponse.model_validate(record)


@quality_router.get("/", response_model=List[QualityResponse])
async def list_quality_records(
    factory_id: UUID = Query(...),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    worker_id: Optional[UUID] = Query(None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    filters = [QualityRecord.factory_id == factory_id]
    if date_from:
        filters.append(QualityRecord.date >= date_from)
    if date_to:
        filters.append(QualityRecord.date <= date_to)
    if worker_id:
        filters.append(QualityRecord.worker_id == worker_id)

    stmt = select(QualityRecord).where(and_(*filters)).order_by(QualityRecord.date.desc())
    result = await db.execute(stmt)
    records = result.scalars().all()
    return [QualityResponse.model_validate(r) for r in records]


async def _trigger_quality_update(factory_id, quality_data, worker_id, db):
    service = RealtimeBroadcastService(db)
    await service.on_quality_entered(factory_id, quality_data, worker_id)


# ─── Leaderboard Router ───────────────────────────────────────────────────────
leaderboard_router = APIRouter(prefix="/leaderboard", tags=["Leaderboard"])


@leaderboard_router.get("/{period_type}", response_model=LeaderboardResponse)
async def get_leaderboard(
    period_type: str,
    factory_id: UUID = Query(...),
    limit: int = Query(default=10, le=50),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get top performers leaderboard. period_type: daily | weekly | monthly"""
    if period_type not in ("daily", "weekly", "monthly"):
        raise HTTPException(status_code=400, detail="Invalid period type")

    today = date.today()
    if period_type == "daily":
        period_start = today
    elif period_type == "weekly":
        period_start = today - __import__("datetime").timedelta(days=today.weekday())
    else:
        period_start = today.replace(day=1)

    stmt = (
        select(PerformanceScore, User)
        .join(User, PerformanceScore.worker_id == User.id)
        .where(
            and_(
                PerformanceScore.factory_id == factory_id,
                PerformanceScore.period_type == period_type,
                PerformanceScore.period_start == period_start,
            )
        )
        .order_by(PerformanceScore.total_score.desc())
        .limit(limit)
    )
    result = await db.execute(stmt)
    rows = result.all()

    entries = []
    for rank, (score, user) in enumerate(rows, start=1):
        entries.append(LeaderboardEntry(
            rank=rank,
            worker=UserBrief.model_validate(user),
            total_score=score.total_score,
            efficiency_score=score.efficiency_score,
            quality_score=score.quality_score,
            attendance_score=score.attendance_score,
            is_bonus_eligible=score.is_bonus_eligible,
        ))

    return LeaderboardResponse(
        period_type=period_type,
        period_start=period_start,
        period_end=today,
        factory_id=factory_id,
        entries=entries,
        generated_at=datetime.now(timezone.utc),
    )


# ─── WebSocket Endpoint ───────────────────────────────────────────────────────
ws_router = APIRouter(tags=["WebSocket"])


@ws_router.websocket("/ws")
async def websocket_endpoint(
    websocket: WebSocket,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_ws_user),
):
    """
    WebSocket endpoint for real-time updates.
    Connect with: ws://server/ws?token=<access_token>

    Events received by client:
    - attendance_marked: worker checked in/out
    - production_entered: supervisor entered production data
    - quality_entered: quality check recorded
    - leaderboard_update: rankings changed
    - performance_recalculated: scores updated
    - bonus_eligible: worker achieved bonus threshold
    - notification: system notification
    - ping: heartbeat (reply with pong)
    """
    if not current_user:
        return

    conn = await ws_manager.connect(
        websocket=websocket,
        user_id=str(current_user.id),
        factory_id=str(current_user.factory_id) if current_user.factory_id else "global",
        role=current_user.role.value,
    )

    try:
        while True:
            # Wait for messages (pong, subscribe, etc.)
            message = await websocket.receive_text()
            await ws_manager.handle_client_message(conn, message)

    except WebSocketDisconnect:
        await ws_manager.disconnect(str(current_user.id))
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"WebSocket error: {e}")
        await ws_manager.disconnect(str(current_user.id))
