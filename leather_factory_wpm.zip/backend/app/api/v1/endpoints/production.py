"""
Production module API endpoints.
Supervisor enters production data → triggers realtime recalculation.
"""
import asyncio
from datetime import date
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Query, status
from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_current_user, require_supervisor, PaginationParams, get_db
from app.models.models import ProductionRecord, User
from app.schemas.schemas import (
    ProductionCreate, ProductionResponse, ProductionSummary, ProductionUpdate,
)
from app.services.performance_service import RealtimeBroadcastService

router = APIRouter(prefix="/production", tags=["Production"])


def _calculate_efficiency(completed: int, target: int) -> float:
    """Calculate efficiency percentage."""
    if target <= 0:
        return 0.0
    return min(999.0, round((completed / target) * 100, 2))


@router.post("/", response_model=ProductionResponse, status_code=status.HTTP_201_CREATED)
async def create_production_record(
    payload: ProductionCreate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """
    Supervisor enters daily production data for a worker.
    Triggers immediate realtime recalculation and broadcast.
    """
    # Check for duplicate (worker + date + shift)
    stmt = select(ProductionRecord).where(
        and_(
            ProductionRecord.worker_id == payload.worker_id,
            ProductionRecord.date == payload.date,
            ProductionRecord.shift == payload.shift,
        )
    )
    result = await db.execute(stmt)
    existing = result.scalar_one_or_none()

    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Production record already exists for worker on {payload.date} ({payload.shift or 'default'} shift). Use PATCH to update.",
        )

    efficiency = _calculate_efficiency(payload.completed_quantity, payload.daily_target)

    record = ProductionRecord(
        worker_id=payload.worker_id,
        supervisor_id=current_user.id,
        factory_id=payload.factory_id,
        production_line_id=payload.production_line_id,
        product_type_id=payload.product_type_id,
        date=payload.date,
        shift=payload.shift,
        daily_target=payload.daily_target,
        completed_quantity=payload.completed_quantity,
        efficiency=efficiency,
        working_hours=payload.working_hours,
        notes=payload.notes,
    )
    db.add(record)
    await db.commit()
    await db.refresh(record)

    # Trigger realtime updates in background (non-blocking)
    production_dict = {
        "id": str(record.id),
        "worker_id": str(record.worker_id),
        "date": record.date.isoformat(),
        "daily_target": record.daily_target,
        "completed_quantity": record.completed_quantity,
        "efficiency": float(record.efficiency),
    }

    background_tasks.add_task(
        _trigger_realtime_update,
        factory_id=str(payload.factory_id),
        worker_id=payload.worker_id,
        production_record=production_dict,
        supervisor_id=str(current_user.id),
        db=db,
    )

    return ProductionResponse.model_validate(record)


@router.patch("/{record_id}", response_model=ProductionResponse)
async def update_production_record(
    record_id: UUID,
    payload: ProductionUpdate,
    background_tasks: BackgroundTasks,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Update an existing production record. Triggers realtime recalculation."""
    stmt = select(ProductionRecord).where(ProductionRecord.id == record_id)
    result = await db.execute(stmt)
    record = result.scalar_one_or_none()

    if not record:
        raise HTTPException(status_code=404, detail="Production record not found")

    # Supervisor can only update records in their factory
    if (current_user.role.value not in ("super_admin", "factory_admin") and
            current_user.factory_id != record.factory_id):
        raise HTTPException(status_code=403, detail="Access denied")

    if payload.completed_quantity is not None:
        record.completed_quantity = payload.completed_quantity
    if payload.daily_target is not None:
        record.daily_target = payload.daily_target
    if payload.notes is not None:
        record.notes = payload.notes
    if payload.working_hours is not None:
        record.working_hours = payload.working_hours

    # Recalculate efficiency
    record.efficiency = _calculate_efficiency(record.completed_quantity, record.daily_target)

    await db.commit()
    await db.refresh(record)

    production_dict = {
        "id": str(record.id),
        "worker_id": str(record.worker_id),
        "date": record.date.isoformat(),
        "completed_quantity": record.completed_quantity,
        "efficiency": float(record.efficiency),
    }

    background_tasks.add_task(
        _trigger_realtime_update,
        factory_id=str(record.factory_id),
        worker_id=record.worker_id,
        production_record=production_dict,
        supervisor_id=str(current_user.id),
        db=db,
    )

    return ProductionResponse.model_validate(record)


@router.get("/", response_model=List[ProductionResponse])
async def list_production_records(
    factory_id: UUID = Query(...),
    date_from: Optional[date] = Query(None),
    date_to: Optional[date] = Query(None),
    worker_id: Optional[UUID] = Query(None),
    production_line_id: Optional[UUID] = Query(None),
    pagination: PaginationParams = Depends(),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List production records with filters."""
    filters = [ProductionRecord.factory_id == factory_id]

    if date_from:
        filters.append(ProductionRecord.date >= date_from)
    if date_to:
        filters.append(ProductionRecord.date <= date_to)
    if worker_id:
        # Workers can only see their own records
        if current_user.role.value == "worker" and current_user.id != worker_id:
            raise HTTPException(status_code=403, detail="Access denied")
        filters.append(ProductionRecord.worker_id == worker_id)
    elif current_user.role.value == "worker":
        filters.append(ProductionRecord.worker_id == current_user.id)
    if production_line_id:
        filters.append(ProductionRecord.production_line_id == production_line_id)

    stmt = (
        select(ProductionRecord)
        .where(and_(*filters))
        .order_by(ProductionRecord.date.desc())
        .offset(pagination.offset)
        .limit(pagination.size)
    )
    result = await db.execute(stmt)
    records = result.scalars().all()

    return [ProductionResponse.model_validate(r) for r in records]


@router.get("/summary", response_model=ProductionSummary)
async def get_production_summary(
    factory_id: UUID = Query(...),
    target_date: date = Query(default=None),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(require_supervisor),
):
    """Get production summary for a factory on a given date."""
    if target_date is None:
        target_date = date.today()

    stmt = select(
        func.count(ProductionRecord.id).label("total_workers"),
        func.avg(ProductionRecord.efficiency).label("avg_efficiency"),
        func.sum(ProductionRecord.completed_quantity).label("total_completed"),
        func.sum(ProductionRecord.daily_target).label("total_target"),
    ).where(
        and_(
            ProductionRecord.factory_id == factory_id,
            ProductionRecord.date == target_date,
        )
    )
    result = await db.execute(stmt)
    row = result.one()

    above_target_stmt = select(func.count(ProductionRecord.id)).where(
        and_(
            ProductionRecord.factory_id == factory_id,
            ProductionRecord.date == target_date,
            ProductionRecord.efficiency >= 100,
        )
    )
    above_result = await db.execute(above_target_stmt)
    above_count = above_result.scalar() or 0

    total = row.total_workers or 0
    below_count = total - above_count

    return ProductionSummary(
        factory_id=factory_id,
        date=target_date,
        total_workers=total,
        avg_efficiency=float(row.avg_efficiency or 0),
        total_completed=int(row.total_completed or 0),
        total_target=int(row.total_target or 0),
        above_target_count=above_count,
        below_target_count=max(0, below_count),
    )


@router.get("/{record_id}", response_model=ProductionResponse)
async def get_production_record(
    record_id: UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    stmt = select(ProductionRecord).where(ProductionRecord.id == record_id)
    result = await db.execute(stmt)
    record = result.scalar_one_or_none()

    if not record:
        raise HTTPException(status_code=404, detail="Not found")

    return ProductionResponse.model_validate(record)


async def _trigger_realtime_update(
    factory_id: str,
    worker_id: UUID,
    production_record: dict,
    supervisor_id: str,
    db: AsyncSession,
):
    """Background task to trigger realtime recalculation and broadcast."""
    try:
        broadcast_service = RealtimeBroadcastService(db)
        await broadcast_service.on_production_entered(
            factory_id=factory_id,
            worker_id=worker_id,
            production_record=production_record,
            supervisor_id=supervisor_id,
        )
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Realtime update failed: {e}", exc_info=True)
