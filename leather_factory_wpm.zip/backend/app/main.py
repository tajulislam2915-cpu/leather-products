"""
Main FastAPI application - Leather Factory WPM System
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from app.core.config import settings
from app.api.v1.endpoints.auth import router as auth_router
from app.api.v1.endpoints.production import router as production_router
from app.api.v1.endpoints.attendance import router as attendance_router
from app.api.v1.endpoints.reports import router as reports_router
from app.api.v1.endpoints.workers_quality_ws import (
    workers_router, quality_router, leaderboard_router, ws_router
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    print("🏭 Leather Factory WPM starting...")
    yield
    print("🏭 Shutting down...")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    lifespan=lifespan,
)

app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Register all routers
prefix = settings.API_V1_STR
app.include_router(auth_router, prefix=prefix)
app.include_router(workers_router, prefix=prefix)
app.include_router(production_router, prefix=prefix)
app.include_router(attendance_router, prefix=prefix)
app.include_router(quality_router, prefix=prefix)
app.include_router(leaderboard_router, prefix=prefix)
app.include_router(reports_router, prefix=prefix)
app.include_router(ws_router)  # WebSocket at /ws


@app.get("/health")
async def health_check():
    return {"status": "ok", "app": settings.APP_NAME, "version": settings.APP_VERSION}
