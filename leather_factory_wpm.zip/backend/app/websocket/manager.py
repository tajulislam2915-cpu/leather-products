"""
Production-grade WebSocket Manager for real-time updates.
Handles connection lifecycle, factory-scoped broadcasts, and heartbeats.
"""
import asyncio
import json
import logging
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set
from uuid import UUID

from fastapi import WebSocket, WebSocketDisconnect

logger = logging.getLogger(__name__)


class ConnectionInfo:
    """Metadata for a single WebSocket connection."""

    def __init__(
        self,
        websocket: WebSocket,
        user_id: str,
        factory_id: str,
        role: str,
    ):
        self.websocket = websocket
        self.user_id = user_id
        self.factory_id = factory_id
        self.role = role
        self.connected_at = datetime.now(timezone.utc)
        self.last_heartbeat = datetime.now(timezone.utc)


class WebSocketManager:
    """
    Manages all WebSocket connections with factory-scoped broadcasting.

    Architecture:
    - connections: factory_id -> Set[ConnectionInfo]
    - Each factory's supervisors/admins receive real-time updates
    - Heartbeat mechanism detects stale connections
    """

    def __init__(self):
        # factory_id -> list of connections in that factory
        self._factory_connections: Dict[str, List[ConnectionInfo]] = {}
        # user_id -> ConnectionInfo (for targeted messages)
        self._user_connections: Dict[str, ConnectionInfo] = {}
        self._lock = asyncio.Lock()

    async def connect(
        self,
        websocket: WebSocket,
        user_id: str,
        factory_id: str,
        role: str,
    ) -> ConnectionInfo:
        """Accept and register a new WebSocket connection."""
        await websocket.accept()

        conn = ConnectionInfo(
            websocket=websocket,
            user_id=user_id,
            factory_id=factory_id,
            role=role,
        )

        async with self._lock:
            if factory_id not in self._factory_connections:
                self._factory_connections[factory_id] = []
            self._factory_connections[factory_id].append(conn)
            self._user_connections[user_id] = conn

        logger.info(f"WS connected: user={user_id} factory={factory_id} role={role}")

        # Send welcome message
        await self._send_to_connection(conn, {
            "event": "connected",
            "message": "Real-time updates active",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        })

        return conn

    async def disconnect(self, user_id: str) -> None:
        """Remove a disconnected user's connection."""
        async with self._lock:
            conn = self._user_connections.pop(user_id, None)
            if conn and conn.factory_id in self._factory_connections:
                try:
                    self._factory_connections[conn.factory_id].remove(conn)
                except ValueError:
                    pass
                if not self._factory_connections[conn.factory_id]:
                    del self._factory_connections[conn.factory_id]

        logger.info(f"WS disconnected: user={user_id}")

    async def broadcast_to_factory(
        self,
        factory_id: str,
        event_type: str,
        data: dict,
        exclude_user_id: Optional[str] = None,
    ) -> int:
        """
        Broadcast a message to all connections in a factory.
        Returns the number of successful sends.
        """
        payload = {
            "event": event_type,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        connections = self._factory_connections.get(factory_id, [])
        if not connections:
            return 0

        stale = []
        sent_count = 0

        for conn in connections:
            if exclude_user_id and conn.user_id == exclude_user_id:
                continue
            success = await self._send_to_connection(conn, payload)
            if success:
                sent_count += 1
            else:
                stale.append(conn)

        # Clean up stale connections
        if stale:
            async with self._lock:
                for conn in stale:
                    try:
                        self._factory_connections[factory_id].remove(conn)
                        self._user_connections.pop(conn.user_id, None)
                    except (ValueError, KeyError):
                        pass

        return sent_count

    async def send_to_user(self, user_id: str, event_type: str, data: dict) -> bool:
        """Send a targeted message to a specific user."""
        conn = self._user_connections.get(user_id)
        if not conn:
            return False

        payload = {
            "event": event_type,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        return await self._send_to_connection(conn, payload)

    async def broadcast_to_role(
        self,
        factory_id: str,
        role: str,
        event_type: str,
        data: dict,
    ) -> int:
        """Broadcast only to connections with a specific role."""
        payload = {
            "event": event_type,
            "data": data,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        connections = [
            c for c in self._factory_connections.get(factory_id, [])
            if c.role == role
        ]

        sent_count = 0
        for conn in connections:
            if await self._send_to_connection(conn, payload):
                sent_count += 1

        return sent_count

    async def _send_to_connection(self, conn: ConnectionInfo, data: dict) -> bool:
        """Attempt to send data to a single connection. Returns False if failed."""
        try:
            await conn.websocket.send_json(data)
            conn.last_heartbeat = datetime.now(timezone.utc)
            return True
        except Exception as e:
            logger.warning(f"WS send failed for user={conn.user_id}: {e}")
            return False

    async def heartbeat_ping(self, conn: ConnectionInfo) -> bool:
        """Send a ping to verify connection is alive."""
        return await self._send_to_connection(conn, {"event": "ping"})

    def get_factory_connection_count(self, factory_id: str) -> int:
        return len(self._factory_connections.get(factory_id, []))

    def get_total_connections(self) -> int:
        return sum(len(conns) for conns in self._factory_connections.values())

    def is_user_connected(self, user_id: str) -> bool:
        return user_id in self._user_connections

    async def handle_client_message(self, conn: ConnectionInfo, message: str) -> None:
        """Handle incoming messages from client (pong, subscribe, etc.)"""
        try:
            data = json.loads(message)
            event = data.get("event")

            if event == "pong":
                conn.last_heartbeat = datetime.now(timezone.utc)
            elif event == "ping":
                await self._send_to_connection(conn, {"event": "pong"})
            elif event == "subscribe":
                # Client can subscribe to specific channels
                pass

        except json.JSONDecodeError:
            logger.warning(f"Invalid WS message from user={conn.user_id}")


# ─── Global singleton manager ─────────────────────────────────────────────────
ws_manager = WebSocketManager()


# ─── WebSocket Event Types ────────────────────────────────────────────────────
class WSEvent:
    """Centralized event type constants for consistency."""
    # Attendance
    ATTENDANCE_MARKED = "attendance_marked"
    ATTENDANCE_UPDATED = "attendance_updated"
    ATTENDANCE_SUMMARY_UPDATE = "attendance_summary_update"

    # Production
    PRODUCTION_ENTERED = "production_entered"
    PRODUCTION_UPDATED = "production_updated"
    PRODUCTION_SUMMARY_UPDATE = "production_summary_update"

    # Quality
    QUALITY_ENTERED = "quality_entered"
    QUALITY_UPDATED = "quality_updated"

    # Performance / Leaderboard
    LEADERBOARD_UPDATE = "leaderboard_update"
    PERFORMANCE_RECALCULATED = "performance_recalculated"
    BONUS_ELIGIBLE = "bonus_eligible"

    # Dashboard
    DASHBOARD_REFRESH = "dashboard_refresh"

    # Notifications
    NOTIFICATION = "notification"

    # System
    PING = "ping"
    PONG = "pong"
    CONNECTED = "connected"
    DISCONNECTED = "disconnected"
