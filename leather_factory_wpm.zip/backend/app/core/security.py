"""
Security utilities: JWT token management, password hashing, RBAC.
Production-grade implementation with refresh token rotation.
"""
from datetime import datetime, timedelta, timezone
from typing import Any, Optional, Union
from uuid import uuid4

from jose import JWTError, jwt
from passlib.context import CryptContext

from app.core.config import settings

# ─── Password Hashing ────────────────────────────────────────────────────────
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a plain password against its hash."""
    return pwd_context.verify(plain_password, hashed_password)


def get_password_hash(password: str) -> str:
    """Generate bcrypt hash of password."""
    return pwd_context.hash(password)


# ─── JWT Token Management ─────────────────────────────────────────────────────
def create_access_token(
    subject: Union[str, Any],
    role: str,
    factory_id: Optional[str] = None,
    expires_delta: Optional[timedelta] = None,
) -> str:
    """Create JWT access token with role and factory context."""
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )

    to_encode = {
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "sub": str(subject),
        "role": role,
        "factory_id": str(factory_id) if factory_id else None,
        "type": "access",
        "jti": str(uuid4()),  # JWT ID for token revocation
    }
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def create_refresh_token(
    subject: Union[str, Any],
    expires_delta: Optional[timedelta] = None,
) -> str:
    """Create JWT refresh token."""
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            days=settings.REFRESH_TOKEN_EXPIRE_DAYS
        )

    to_encode = {
        "exp": expire,
        "iat": datetime.now(timezone.utc),
        "sub": str(subject),
        "type": "refresh",
        "jti": str(uuid4()),
    }
    return jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.ALGORITHM)


def decode_token(token: str) -> dict:
    """Decode and validate a JWT token. Raises JWTError on failure."""
    return jwt.decode(token, settings.SECRET_KEY, algorithms=[settings.ALGORITHM])


# ─── Role-Based Access Control ────────────────────────────────────────────────
class UserRole:
    SUPER_ADMIN = "super_admin"
    FACTORY_ADMIN = "factory_admin"
    SUPERVISOR = "supervisor"
    WORKER = "worker"

    ALL_ROLES = [SUPER_ADMIN, FACTORY_ADMIN, SUPERVISOR, WORKER]

    # Role hierarchy: higher index = more permissions
    HIERARCHY = {
        WORKER: 0,
        SUPERVISOR: 1,
        FACTORY_ADMIN: 2,
        SUPER_ADMIN: 3,
    }

    @classmethod
    def has_permission(cls, user_role: str, required_role: str) -> bool:
        """Check if user_role has at least required_role permissions."""
        user_level = cls.HIERARCHY.get(user_role, -1)
        required_level = cls.HIERARCHY.get(required_role, 999)
        return user_level >= required_level

    @classmethod
    def is_admin_or_above(cls, role: str) -> bool:
        return cls.has_permission(role, cls.FACTORY_ADMIN)

    @classmethod
    def is_supervisor_or_above(cls, role: str) -> bool:
        return cls.has_permission(role, cls.SUPERVISOR)


# ─── Permission Definitions ───────────────────────────────────────────────────
PERMISSIONS = {
    # Worker Management
    "worker:create": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "worker:read": [UserRole.WORKER, UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "worker:update": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "worker:delete": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "worker:transfer": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],

    # Production Data
    "production:create": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "production:read": [UserRole.WORKER, UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "production:update": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "production:delete": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],

    # Attendance
    "attendance:create": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "attendance:read": [UserRole.WORKER, UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "attendance:update": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],

    # Quality
    "quality:create": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "quality:read": [UserRole.WORKER, UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],

    # Reports
    "report:generate": [UserRole.SUPERVISOR, UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "report:export": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],

    # Admin
    "department:manage": [UserRole.FACTORY_ADMIN, UserRole.SUPER_ADMIN],
    "factory:manage": [UserRole.SUPER_ADMIN],
}


def check_permission(user_role: str, permission: str) -> bool:
    """Check if a role has a specific permission."""
    allowed_roles = PERMISSIONS.get(permission, [])
    return user_role in allowed_roles
