"""
Core configuration settings for the Leather Factory WPM System.
Uses pydantic-settings for environment variable management.
"""
from functools import lru_cache
from typing import List, Optional
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import AnyHttpUrl, validator


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=True,
    )

    # ─── Application ────────────────────────────────────────────────────────────
    APP_NAME: str = "Leather Factory WPM"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"  # development | staging | production

    # ─── API ────────────────────────────────────────────────────────────────────
    API_V1_STR: str = "/api/v1"
    SECRET_KEY: str = "CHANGE_THIS_IN_PRODUCTION_USE_256_BIT_RANDOM_KEY"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_DAYS: int = 7

    # ─── Database ───────────────────────────────────────────────────────────────
    POSTGRES_SERVER: str = "localhost"
    POSTGRES_PORT: int = 5432
    POSTGRES_USER: str = "wpm_user"
    POSTGRES_PASSWORD: str = "CHANGE_THIS_PASSWORD"
    POSTGRES_DB: str = "leather_wpm"

    @property
    def DATABASE_URL(self) -> str:
        return (
            f"postgresql+asyncpg://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    @property
    def DATABASE_URL_SYNC(self) -> str:
        return (
            f"postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}"
            f"@{self.POSTGRES_SERVER}:{self.POSTGRES_PORT}/{self.POSTGRES_DB}"
        )

    # ─── Redis ──────────────────────────────────────────────────────────────────
    REDIS_HOST: str = "localhost"
    REDIS_PORT: int = 6379
    REDIS_PASSWORD: Optional[str] = None
    REDIS_DB: int = 0

    @property
    def REDIS_URL(self) -> str:
        if self.REDIS_PASSWORD:
            return f"redis://:{self.REDIS_PASSWORD}@{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"
        return f"redis://{self.REDIS_HOST}:{self.REDIS_PORT}/{self.REDIS_DB}"

    # ─── CORS ───────────────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = [
        "http://localhost:3000",
        "http://localhost:8080",
        "https://yourdomain.com",
    ]

    # ─── Firebase (Push Notifications) ──────────────────────────────────────────
    FIREBASE_CREDENTIALS_PATH: Optional[str] = None
    FIREBASE_PROJECT_ID: Optional[str] = None

    # ─── AWS S3 (File Storage) ───────────────────────────────────────────────────
    AWS_ACCESS_KEY_ID: Optional[str] = None
    AWS_SECRET_ACCESS_KEY: Optional[str] = None
    AWS_BUCKET_NAME: Optional[str] = None
    AWS_REGION: str = "us-east-1"

    # ─── File Upload ─────────────────────────────────────────────────────────────
    MAX_UPLOAD_SIZE: int = 10 * 1024 * 1024  # 10MB
    UPLOAD_DIR: str = "uploads"

    # ─── Performance Calculation ──────────────────────────────────────────────────
    EFFICIENCY_WEIGHT: float = 0.40       # 40% of performance score
    QUALITY_WEIGHT: float = 0.35          # 35% of performance score
    ATTENDANCE_WEIGHT: float = 0.25       # 25% of performance score

    # ─── Bonus Thresholds ────────────────────────────────────────────────────────
    BONUS_EFFICIENCY_THRESHOLD: float = 90.0   # >= 90% efficiency
    BONUS_QUALITY_THRESHOLD: float = 95.0      # >= 95% quality
    BONUS_ATTENDANCE_THRESHOLD: float = 95.0   # >= 95% attendance

    # ─── WebSocket ───────────────────────────────────────────────────────────────
    WS_HEARTBEAT_INTERVAL: int = 30  # seconds


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
