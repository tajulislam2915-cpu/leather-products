"""
FastAPI dependency injection: authentication, authorization, DB sessions.
"""
import logging
from typing import Optional
from uuid import UUID

from fastapi import Depends, HTTPException, Query, WebSocket, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import decode_token, UserRole, check_permission
from app.db.database import get_db
from app.models.models import User

logger = logging.getLogger(__name__)
security = HTTPBearer()


# ─── Get Current User ─────────────────────────────────────────────────────────
async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Extract and validate JWT, return current User from DB."""
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = decode_token(credentials.credentials)
        user_id: str = payload.get("sub")
        token_type: str = payload.get("type")

        if not user_id or token_type != "access":
            raise credentials_exception

    except JWTError as e:
        logger.warning(f"JWT validation failed: {e}")
        raise credentials_exception

    stmt = select(User).where(User.id == UUID(user_id), User.is_deleted == False)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()

    if not user:
        raise credentials_exception

    if not user.is_active:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Account is deactivated",
        )

    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    return current_user


# ─── Role Requirements ────────────────────────────────────────────────────────
def require_role(*roles: str):
    """Factory for role-based access dependencies."""
    async def _dependency(current_user: User = Depends(get_current_user)) -> User:
        if current_user.role.value not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Access denied. Required roles: {', '.join(roles)}",
            )
        return current_user
    return _dependency


def require_permission(permission: str):
    """Factory for permission-based access dependencies."""
    async def _dependency(current_user: User = Depends(get_current_user)) -> User:
        if not check_permission(current_user.role.value, permission):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Permission denied: {permission}",
            )
        return current_user
    return _dependency


# ─── Convenience role deps ────────────────────────────────────────────────────
require_super_admin = require_role(UserRole.SUPER_ADMIN)
require_factory_admin = require_role(UserRole.SUPER_ADMIN, UserRole.FACTORY_ADMIN)
require_supervisor = require_role(
    UserRole.SUPER_ADMIN, UserRole.FACTORY_ADMIN, UserRole.SUPERVISOR
)


# ─── Factory Access Guard ─────────────────────────────────────────────────────
async def verify_factory_access(
    factory_id: UUID,
    current_user: User = Depends(get_current_user),
) -> UUID:
    """
    Ensure current user has access to the requested factory.
    Super admins can access any factory; others only their own.
    """
    if current_user.role.value == UserRole.SUPER_ADMIN:
        return factory_id

    if current_user.factory_id != factory_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this factory",
        )

    return factory_id


# ─── WebSocket Auth ───────────────────────────────────────────────────────────
async def get_ws_user(
    websocket: WebSocket,
    token: str = Query(..., description="JWT access token"),
    db: AsyncSession = Depends(get_db),
) -> Optional[User]:
    """Authenticate WebSocket connections via query parameter token."""
    try:
        payload = decode_token(token)
        user_id = payload.get("sub")
        token_type = payload.get("type")

        if not user_id or token_type != "access":
            await websocket.close(code=4001, reason="Invalid token")
            return None

        stmt = select(User).where(User.id == UUID(user_id), User.is_active == True)
        result = await db.execute(stmt)
        user = result.scalar_one_or_none()

        if not user:
            await websocket.close(code=4002, reason="User not found")
            return None

        return user

    except JWTError:
        await websocket.close(code=4001, reason="Token validation failed")
        return None


# ─── Pagination ───────────────────────────────────────────────────────────────
class PaginationParams:
    def __init__(
        self,
        page: int = Query(default=1, ge=1),
        size: int = Query(default=20, ge=1, le=100),
    ):
        self.page = page
        self.size = size

    @property
    def offset(self) -> int:
        return (self.page - 1) * self.size
