"""
Pydantic v2 schemas for request/response validation.
All API input/output models defined here.
"""
from datetime import date, datetime
from decimal import Decimal
from typing import Any, Dict, List, Optional
from uuid import UUID

from pydantic import BaseModel, EmailStr, Field, computed_field, model_validator


# ─── Base ─────────────────────────────────────────────────────────────────────
class BaseSchema(BaseModel):
    model_config = {"from_attributes": True}


# ─── Token / Auth ─────────────────────────────────────────────────────────────
class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6)


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: "UserBrief"


class RefreshRequest(BaseModel):
    refresh_token: str


class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str = Field(min_length=8)


# ─── Factory ──────────────────────────────────────────────────────────────────
class FactoryCreate(BaseModel):
    name: str = Field(max_length=200)
    code: str = Field(max_length=20)
    address: Optional[str] = None
    city: Optional[str] = None
    country: str = "Bangladesh"
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    timezone: str = "Asia/Dhaka"


class FactoryUpdate(BaseModel):
    name: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[EmailStr] = None
    is_active: Optional[bool] = None


class FactoryResponse(BaseSchema):
    id: UUID
    name: str
    code: str
    address: Optional[str]
    city: Optional[str]
    country: str
    phone: Optional[str]
    email: Optional[str]
    timezone: str
    is_active: bool
    created_at: datetime


# ─── Department ───────────────────────────────────────────────────────────────
class DepartmentCreate(BaseModel):
    factory_id: UUID
    name: str = Field(max_length=200)
    code: str = Field(max_length=20)
    description: Optional[str] = None
    manager_id: Optional[UUID] = None


class DepartmentUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    manager_id: Optional[UUID] = None
    is_active: Optional[bool] = None


class DepartmentResponse(BaseSchema):
    id: UUID
    factory_id: UUID
    name: str
    code: str
    description: Optional[str]
    is_active: bool
    created_at: datetime


# ─── Production Line ──────────────────────────────────────────────────────────
class ProductionLineCreate(BaseModel):
    factory_id: UUID
    department_id: Optional[UUID] = None
    name: str = Field(max_length=200)
    code: str = Field(max_length=20)
    capacity: Optional[int] = None


class ProductionLineResponse(BaseSchema):
    id: UUID
    factory_id: UUID
    department_id: Optional[UUID]
    name: str
    code: str
    capacity: Optional[int]
    is_active: bool


# ─── User / Worker ────────────────────────────────────────────────────────────
class UserCreate(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8)
    role: str = Field(pattern="^(super_admin|factory_admin|supervisor|worker)$")
    factory_id: Optional[UUID] = None
    department_id: Optional[UUID] = None
    production_line_id: Optional[UUID] = None
    employee_id: str = Field(max_length=50)
    first_name: str = Field(max_length=100)
    last_name: str = Field(max_length=100)
    gender: Optional[str] = None
    date_of_birth: Optional[date] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    designation: Optional[str] = None
    shift: Optional[str] = None
    join_date: Optional[date] = None
    daily_target: Optional[int] = Field(None, gt=0)
    base_salary: Optional[Decimal] = None
    rfid_card_number: Optional[str] = None


class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    address: Optional[str] = None
    designation: Optional[str] = None
    shift: Optional[str] = None
    daily_target: Optional[int] = Field(None, gt=0)
    base_salary: Optional[Decimal] = None
    department_id: Optional[UUID] = None
    production_line_id: Optional[UUID] = None
    rfid_card_number: Optional[str] = None
    is_active: Optional[bool] = None


class UserBrief(BaseSchema):
    id: UUID
    email: str
    role: str
    employee_id: str
    first_name: str
    last_name: str
    factory_id: Optional[UUID]
    department_id: Optional[UUID]
    profile_photo_url: Optional[str]

    @computed_field
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


class UserResponse(BaseSchema):
    id: UUID
    email: str
    role: str
    factory_id: Optional[UUID]
    department_id: Optional[UUID]
    production_line_id: Optional[UUID]
    employee_id: str
    first_name: str
    last_name: str
    gender: Optional[str]
    date_of_birth: Optional[date]
    phone: Optional[str]
    address: Optional[str]
    profile_photo_url: Optional[str]
    designation: Optional[str]
    shift: Optional[str]
    join_date: Optional[date]
    daily_target: Optional[int]
    base_salary: Optional[Decimal]
    rfid_card_number: Optional[str]
    is_active: bool
    is_verified: bool
    last_login: Optional[datetime]
    created_at: datetime

    @computed_field
    @property
    def full_name(self) -> str:
        return f"{self.first_name} {self.last_name}"


class WorkerTransferRequest(BaseModel):
    worker_id: UUID
    to_department_id: Optional[UUID] = None
    to_production_line_id: Optional[UUID] = None
    to_factory_id: Optional[UUID] = None
    effective_date: date
    reason: Optional[str] = None


# ─── Attendance ───────────────────────────────────────────────────────────────
class AttendanceCreate(BaseModel):
    worker_id: UUID
    date: date
    status: str = Field(pattern="^(present|absent|late|half_day|on_leave)$")
    method: str = Field(default="manual", pattern="^(qr_code|rfid|manual|face_recognition)$")
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    shift: Optional[str] = None
    notes: Optional[str] = None
    overtime_hours: Decimal = Field(default=0, ge=0)


class AttendanceBulkCreate(BaseModel):
    factory_id: UUID
    date: date
    records: List[AttendanceCreate]


class QRAttendanceRequest(BaseModel):
    qr_code: str
    factory_id: UUID
    date: Optional[date] = None
    action: str = Field(pattern="^(check_in|check_out)$")


class RFIDAttendanceRequest(BaseModel):
    rfid_card: str
    factory_id: UUID
    action: str = Field(pattern="^(check_in|check_out)$")


class AttendanceUpdate(BaseModel):
    status: Optional[str] = None
    check_in_time: Optional[datetime] = None
    check_out_time: Optional[datetime] = None
    notes: Optional[str] = None
    overtime_hours: Optional[Decimal] = None


class AttendanceResponse(BaseSchema):
    id: UUID
    worker_id: UUID
    factory_id: UUID
    date: date
    check_in_time: Optional[datetime]
    check_out_time: Optional[datetime]
    status: str
    method: str
    shift: Optional[str]
    notes: Optional[str]
    overtime_hours: Decimal
    created_at: datetime
    worker: Optional[UserBrief] = None


class AttendanceSummary(BaseModel):
    factory_id: UUID
    date: date
    total_workers: int
    present: int
    absent: int
    late: int
    half_day: int
    on_leave: int
    attendance_rate: float


# ─── Production ───────────────────────────────────────────────────────────────
class ProductionCreate(BaseModel):
    worker_id: UUID
    factory_id: UUID
    production_line_id: Optional[UUID] = None
    product_type_id: Optional[UUID] = None
    date: date
    shift: Optional[str] = None
    daily_target: int = Field(gt=0)
    completed_quantity: int = Field(ge=0)
    working_hours: Optional[Decimal] = Field(None, ge=0, le=24)
    notes: Optional[str] = None

    @model_validator(mode="after")
    def calculate_efficiency(self) -> "ProductionCreate":
        # Efficiency is calculated server-side
        return self


class ProductionUpdate(BaseModel):
    completed_quantity: Optional[int] = Field(None, ge=0)
    daily_target: Optional[int] = Field(None, gt=0)
    notes: Optional[str] = None
    working_hours: Optional[Decimal] = None


class ProductionResponse(BaseSchema):
    id: UUID
    worker_id: UUID
    supervisor_id: UUID
    factory_id: UUID
    production_line_id: Optional[UUID]
    product_type_id: Optional[UUID]
    date: date
    shift: Optional[str]
    daily_target: int
    completed_quantity: int
    efficiency: Decimal
    working_hours: Optional[Decimal]
    notes: Optional[str]
    created_at: datetime
    worker: Optional[UserBrief] = None


class ProductionSummary(BaseModel):
    factory_id: UUID
    date: date
    total_workers: int
    avg_efficiency: float
    total_completed: int
    total_target: int
    above_target_count: int
    below_target_count: int


# ─── Quality ──────────────────────────────────────────────────────────────────
class QualityCreate(BaseModel):
    production_record_id: UUID
    worker_id: UUID
    factory_id: UUID
    date: date
    produced_quantity: int = Field(gt=0)
    defective_quantity: int = Field(ge=0)
    defect_categories: Optional[Dict[str, int]] = None
    notes: Optional[str] = None

    @model_validator(mode="after")
    def validate_defective(self) -> "QualityCreate":
        if self.defective_quantity > self.produced_quantity:
            raise ValueError("Defective quantity cannot exceed produced quantity")
        return self


class QualityResponse(BaseSchema):
    id: UUID
    production_record_id: UUID
    worker_id: UUID
    supervisor_id: UUID
    factory_id: UUID
    date: date
    produced_quantity: int
    defective_quantity: int
    quality_score: Decimal
    defect_categories: Optional[Dict]
    notes: Optional[str]
    created_at: datetime
    worker: Optional[UserBrief] = None


# ─── Performance ──────────────────────────────────────────────────────────────
class PerformanceResponse(BaseSchema):
    id: UUID
    worker_id: UUID
    factory_id: UUID
    score_date: date
    period_type: str
    period_start: date
    period_end: date
    efficiency_score: Decimal
    quality_score: Decimal
    attendance_score: Decimal
    total_score: Decimal
    rank: Optional[int]
    total_workers: Optional[int]
    is_bonus_eligible: bool
    bonus_amount: Optional[Decimal]
    worker: Optional[UserBrief] = None


class LeaderboardEntry(BaseModel):
    rank: int
    worker: UserBrief
    total_score: Decimal
    efficiency_score: Decimal
    quality_score: Decimal
    attendance_score: Decimal
    is_bonus_eligible: bool


class LeaderboardResponse(BaseModel):
    period_type: str
    period_start: date
    period_end: date
    factory_id: UUID
    entries: List[LeaderboardEntry]
    generated_at: datetime


# ─── Dashboard ────────────────────────────────────────────────────────────────
class DashboardStats(BaseModel):
    date: date
    factory_id: UUID

    # Attendance
    total_workers: int
    present_today: int
    absent_today: int
    attendance_rate: float

    # Production
    avg_efficiency: float
    total_produced: int
    total_target: int
    top_performers: List[LeaderboardEntry]

    # Quality
    avg_quality_score: float
    total_defects: int
    defect_rate: float

    # Alerts
    bonus_eligible_count: int
    target_miss_count: int


class RealtimeUpdate(BaseModel):
    """Payload broadcast via WebSocket on data changes."""
    event_type: str  # attendance_update | production_update | quality_update | leaderboard_update
    factory_id: str
    data: Dict[str, Any]
    timestamp: datetime


# ─── Reports ─────────────────────────────────────────────────────────────────
class ReportFilter(BaseModel):
    factory_id: UUID
    start_date: date
    end_date: date
    department_id: Optional[UUID] = None
    worker_id: Optional[UUID] = None
    production_line_id: Optional[UUID] = None
    report_type: str = Field(pattern="^(attendance|production|quality|performance)$")
    format: str = Field(default="pdf", pattern="^(pdf|excel|csv)$")


# ─── Pagination ───────────────────────────────────────────────────────────────
class PaginatedResponse(BaseModel):
    items: List[Any]
    total: int
    page: int
    size: int
    pages: int


# ─── Notification ─────────────────────────────────────────────────────────────
class NotificationResponse(BaseSchema):
    id: UUID
    type: str
    title: str
    body: str
    data: Optional[Dict]
    is_read: bool
    read_at: Optional[datetime]
    created_at: datetime


# ─── QR Code ─────────────────────────────────────────────────────────────────
class QRCodeResponse(BaseModel):
    worker_id: UUID
    employee_id: str
    qr_code_data: str
    qr_code_image_base64: str


# ─── Update type hints ────────────────────────────────────────────────────────
TokenResponse.model_rebuild()
