"""
Core service layer: performance calculation, bonus evaluation, notifications.
Called after every production/quality/attendance record change.
"""
import asyncio
import logging
from datetime import date, timedelta
from decimal import Decimal
from typing import Dict, List, Optional
from uuid import UUID

from sqlalchemy import and_, func, select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.models.models import (
    AttendanceRecord, AttendanceStatusEnum, PerformanceScore,
    ProductionRecord, QualityRecord, User, Notification, NotificationTypeEnum,
)
from app.websocket.manager import ws_manager, WSEvent

logger = logging.getLogger(__name__)


# ─── Performance Calculation Service ─────────────────────────────────────────
class PerformanceCalculationService:
    """
    Calculates weighted performance scores for workers.

    Formula:
    - Efficiency Score  = avg(completed/target * 100) for period
    - Quality Score     = avg(quality_score) for period
    - Attendance Score  = (present_days / working_days) * 100
    - Total Score       = efficiency * 0.40 + quality * 0.35 + attendance * 0.25
    """

    def __init__(self, db: AsyncSession):
        self.db = db

    async def calculate_daily(self, worker_id: UUID, factory_id: UUID, target_date: date) -> PerformanceScore:
        """Calculate and persist daily performance score."""
        period_start = target_date
        period_end = target_date

        efficiency_score = await self._get_efficiency_score(worker_id, period_start, period_end)
        quality_score = await self._get_quality_score(worker_id, period_start, period_end)
        attendance_score = await self._get_attendance_score(worker_id, period_start, period_end)

        total_score = self._compute_total(efficiency_score, quality_score, attendance_score)
        is_bonus_eligible = self._check_bonus_eligibility(efficiency_score, quality_score, attendance_score)

        return await self._upsert_performance_score(
            worker_id=worker_id,
            factory_id=factory_id,
            score_date=target_date,
            period_type="daily",
            period_start=period_start,
            period_end=period_end,
            efficiency_score=efficiency_score,
            quality_score=quality_score,
            attendance_score=attendance_score,
            total_score=total_score,
            is_bonus_eligible=is_bonus_eligible,
        )

    async def calculate_weekly(self, worker_id: UUID, factory_id: UUID, any_date: date) -> PerformanceScore:
        """Calculate weekly performance (Mon-Sun of the week containing any_date)."""
        monday = any_date - timedelta(days=any_date.weekday())
        sunday = monday + timedelta(days=6)

        efficiency_score = await self._get_efficiency_score(worker_id, monday, sunday)
        quality_score = await self._get_quality_score(worker_id, monday, sunday)
        attendance_score = await self._get_attendance_score(worker_id, monday, sunday)

        total_score = self._compute_total(efficiency_score, quality_score, attendance_score)
        is_bonus_eligible = self._check_bonus_eligibility(efficiency_score, quality_score, attendance_score)

        return await self._upsert_performance_score(
            worker_id=worker_id,
            factory_id=factory_id,
            score_date=any_date,
            period_type="weekly",
            period_start=monday,
            period_end=sunday,
            efficiency_score=efficiency_score,
            quality_score=quality_score,
            attendance_score=attendance_score,
            total_score=total_score,
            is_bonus_eligible=is_bonus_eligible,
        )

    async def calculate_monthly(self, worker_id: UUID, factory_id: UUID, any_date: date) -> PerformanceScore:
        """Calculate monthly performance."""
        period_start = any_date.replace(day=1)
        # Last day of month
        if any_date.month == 12:
            period_end = any_date.replace(year=any_date.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            period_end = any_date.replace(month=any_date.month + 1, day=1) - timedelta(days=1)

        efficiency_score = await self._get_efficiency_score(worker_id, period_start, period_end)
        quality_score = await self._get_quality_score(worker_id, period_start, period_end)
        attendance_score = await self._get_attendance_score(worker_id, period_start, period_end)

        total_score = self._compute_total(efficiency_score, quality_score, attendance_score)
        is_bonus_eligible = self._check_bonus_eligibility(efficiency_score, quality_score, attendance_score)

        return await self._upsert_performance_score(
            worker_id=worker_id,
            factory_id=factory_id,
            score_date=any_date,
            period_type="monthly",
            period_start=period_start,
            period_end=period_end,
            efficiency_score=efficiency_score,
            quality_score=quality_score,
            attendance_score=attendance_score,
            total_score=total_score,
            is_bonus_eligible=is_bonus_eligible,
        )

    async def recalculate_rankings(
        self, factory_id: UUID, period_type: str, period_start: date
    ) -> List[Dict]:
        """
        Recalculate rankings for all workers in a factory/period.
        Returns sorted leaderboard data for WebSocket broadcast.
        """
        stmt = (
            select(PerformanceScore)
            .where(
                and_(
                    PerformanceScore.factory_id == factory_id,
                    PerformanceScore.period_type == period_type,
                    PerformanceScore.period_start == period_start,
                )
            )
            .order_by(PerformanceScore.total_score.desc())
        )
        result = await self.db.execute(stmt)
        scores = result.scalars().all()

        total_workers = len(scores)
        leaderboard = []

        for rank, score in enumerate(scores, start=1):
            score.rank = rank
            score.total_workers = total_workers
            leaderboard.append({
                "rank": rank,
                "worker_id": str(score.worker_id),
                "total_score": float(score.total_score),
                "efficiency_score": float(score.efficiency_score),
                "quality_score": float(score.quality_score),
                "attendance_score": float(score.attendance_score),
                "is_bonus_eligible": score.is_bonus_eligible,
            })

        await self.db.commit()
        return leaderboard

    async def _get_efficiency_score(self, worker_id: UUID, start: date, end: date) -> Decimal:
        stmt = (
            select(func.avg(ProductionRecord.efficiency))
            .where(
                and_(
                    ProductionRecord.worker_id == worker_id,
                    ProductionRecord.date >= start,
                    ProductionRecord.date <= end,
                )
            )
        )
        result = await self.db.execute(stmt)
        avg = result.scalar()
        return Decimal(str(avg)) if avg else Decimal("0")

    async def _get_quality_score(self, worker_id: UUID, start: date, end: date) -> Decimal:
        stmt = (
            select(func.avg(QualityRecord.quality_score))
            .where(
                and_(
                    QualityRecord.worker_id == worker_id,
                    QualityRecord.date >= start,
                    QualityRecord.date <= end,
                )
            )
        )
        result = await self.db.execute(stmt)
        avg = result.scalar()
        return Decimal(str(avg)) if avg else Decimal("100")  # No defects = 100%

    async def _get_attendance_score(self, worker_id: UUID, start: date, end: date) -> Decimal:
        """Count working days in range vs present days."""
        total_days = (end - start).days + 1

        stmt = (
            select(func.count(AttendanceRecord.id))
            .where(
                and_(
                    AttendanceRecord.worker_id == worker_id,
                    AttendanceRecord.date >= start,
                    AttendanceRecord.date <= end,
                    AttendanceRecord.status.in_([
                        AttendanceStatusEnum.PRESENT,
                        AttendanceStatusEnum.LATE,
                    ]),
                )
            )
        )
        result = await self.db.execute(stmt)
        present_days = result.scalar() or 0

        if total_days == 0:
            return Decimal("0")

        return Decimal(str(min(100, (present_days / total_days) * 100)))

    def _compute_total(
        self,
        efficiency: Decimal,
        quality: Decimal,
        attendance: Decimal,
    ) -> Decimal:
        return (
            efficiency * Decimal(str(settings.EFFICIENCY_WEIGHT)) +
            quality * Decimal(str(settings.QUALITY_WEIGHT)) +
            attendance * Decimal(str(settings.ATTENDANCE_WEIGHT))
        ).quantize(Decimal("0.01"))

    def _check_bonus_eligibility(
        self,
        efficiency: Decimal,
        quality: Decimal,
        attendance: Decimal,
    ) -> bool:
        return (
            efficiency >= Decimal(str(settings.BONUS_EFFICIENCY_THRESHOLD)) and
            quality >= Decimal(str(settings.BONUS_QUALITY_THRESHOLD)) and
            attendance >= Decimal(str(settings.BONUS_ATTENDANCE_THRESHOLD))
        )

    async def _upsert_performance_score(self, **kwargs) -> PerformanceScore:
        """Create or update a performance score record."""
        worker_id = kwargs["worker_id"]
        period_type = kwargs["period_type"]
        period_start = kwargs["period_start"]

        stmt = select(PerformanceScore).where(
            and_(
                PerformanceScore.worker_id == worker_id,
                PerformanceScore.period_type == period_type,
                PerformanceScore.period_start == period_start,
            )
        )
        result = await self.db.execute(stmt)
        existing = result.scalar_one_or_none()

        if existing:
            for key, value in kwargs.items():
                setattr(existing, key, value)
            await self.db.commit()
            await self.db.refresh(existing)
            return existing
        else:
            score = PerformanceScore(**kwargs)
            self.db.add(score)
            await self.db.commit()
            await self.db.refresh(score)
            return score


# ─── Notification Service ─────────────────────────────────────────────────────
class NotificationService:
    """Handles in-app and push notifications."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def send_bonus_eligible_notification(
        self, worker: User, period_type: str
    ) -> None:
        """Notify worker they are bonus eligible."""
        notification = Notification(
            recipient_id=worker.id,
            factory_id=worker.factory_id,
            type=NotificationTypeEnum.BONUS_ELIGIBLE,
            title="🎉 Bonus Eligible!",
            body=f"Congratulations {worker.first_name}! You are eligible for a bonus this {period_type}.",
            data={"period_type": period_type},
        )
        self.db.add(notification)
        await self.db.commit()

        # Send realtime WS notification
        if worker.factory_id:
            await ws_manager.send_to_user(
                str(worker.id),
                WSEvent.BONUS_ELIGIBLE,
                {
                    "title": notification.title,
                    "body": notification.body,
                    "period_type": period_type,
                },
            )

    async def send_target_miss_alert(
        self, worker: User, efficiency: float, supervisor_id: str
    ) -> None:
        """Alert supervisor when worker misses target."""
        notification = Notification(
            recipient_id=UUID(supervisor_id),
            factory_id=worker.factory_id,
            type=NotificationTypeEnum.TARGET_MISS,
            title="⚠️ Target Miss Alert",
            body=f"{worker.full_name} achieved only {efficiency:.1f}% efficiency today.",
            data={"worker_id": str(worker.id), "efficiency": efficiency},
        )
        self.db.add(notification)
        await self.db.commit()

        await ws_manager.send_to_user(
            supervisor_id,
            WSEvent.NOTIFICATION,
            {
                "type": "target_miss",
                "title": notification.title,
                "body": notification.body,
            },
        )


# ─── Realtime Broadcast Service ───────────────────────────────────────────────
class RealtimeBroadcastService:
    """
    Orchestrates all real-time updates after data changes.
    Called by API endpoints after successful DB writes.
    """

    def __init__(self, db: AsyncSession):
        self.db = db
        self.perf_service = PerformanceCalculationService(db)
        self.notif_service = NotificationService(db)

    async def on_production_entered(
        self,
        factory_id: str,
        worker_id: UUID,
        production_record: dict,
        supervisor_id: str,
    ) -> None:
        """
        Triggered when supervisor enters production data.
        1. Recalculate performance scores (daily + weekly + monthly)
        2. Update rankings
        3. Broadcast to all factory connections
        4. Send notifications if eligible
        """
        try:
            today = date.today()
            factory_uuid = UUID(factory_id)

            # Recalculate all period scores
            daily_score = await self.perf_service.calculate_daily(worker_id, factory_uuid, today)
            await self.perf_service.calculate_weekly(worker_id, factory_uuid, today)
            await self.perf_service.calculate_monthly(worker_id, factory_uuid, today)

            # Recalculate factory rankings for daily leaderboard
            daily_leaderboard = await self.perf_service.recalculate_rankings(
                factory_uuid, "daily", today
            )

            # Broadcast production update
            await ws_manager.broadcast_to_factory(
                factory_id,
                WSEvent.PRODUCTION_ENTERED,
                {
                    "production": production_record,
                    "worker_efficiency": float(daily_score.efficiency_score),
                },
            )

            # Broadcast leaderboard update
            await ws_manager.broadcast_to_factory(
                factory_id,
                WSEvent.LEADERBOARD_UPDATE,
                {
                    "period_type": "daily",
                    "period_start": today.isoformat(),
                    "leaderboard": daily_leaderboard[:10],  # Top 10
                },
            )

            # Check bonus eligibility
            if daily_score.is_bonus_eligible:
                worker_stmt = select(User).where(User.id == worker_id)
                result = await self.db.execute(worker_stmt)
                worker = result.scalar_one_or_none()
                if worker:
                    await self.notif_service.send_bonus_eligible_notification(worker, "day")

            # Alert on low efficiency
            if daily_score.efficiency_score < Decimal("70"):
                worker_stmt = select(User).where(User.id == worker_id)
                result = await self.db.execute(worker_stmt)
                worker = result.scalar_one_or_none()
                if worker:
                    await self.notif_service.send_target_miss_alert(
                        worker, float(daily_score.efficiency_score), supervisor_id
                    )

        except Exception as e:
            logger.error(f"Error in on_production_entered: {e}", exc_info=True)

    async def on_attendance_marked(self, factory_id: str, attendance_data: dict) -> None:
        """Broadcast attendance updates to factory dashboard."""
        await ws_manager.broadcast_to_factory(
            factory_id,
            WSEvent.ATTENDANCE_MARKED,
            attendance_data,
        )

    async def on_quality_entered(
        self, factory_id: str, quality_data: dict, worker_id: UUID
    ) -> None:
        """Recalculate quality component and broadcast."""
        try:
            today = date.today()
            factory_uuid = UUID(factory_id)

            # Recalculate scores with new quality data
            daily_score = await self.perf_service.calculate_daily(worker_id, factory_uuid, today)

            await ws_manager.broadcast_to_factory(
                factory_id,
                WSEvent.QUALITY_ENTERED,
                {
                    "quality": quality_data,
                    "new_quality_score": float(daily_score.quality_score),
                },
            )

        except Exception as e:
            logger.error(f"Error in on_quality_entered: {e}", exc_info=True)
